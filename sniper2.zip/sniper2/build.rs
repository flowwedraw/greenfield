fn main() {
    // 1) используем встроенный protoc
    let protoc = protoc_bin_vendored::protoc_bin_path().expect("no protoc binary");
    std::env::set_var("PROTOC", protoc);

    // 2) well-known types (google/protobuf/*.proto)
    let wkts = protoc_bin_vendored::include_path().expect("include path");
    let wkts_str = wkts.to_str().expect("utf8 include path");

    // 3) компиляция jito-protos
    tonic_build::configure()
        .protoc_arg("--experimental_allow_proto3_optional")
        .compile_protos(
            &[
                "jito-protos/bundle.proto",
                "jito-protos/packet.proto",
                "jito-protos/searcher.proto",
                "jito-protos/shared.proto",
            ],
            &[
                "jito-protos", // наши .proto
                wkts_str,      // well-known types (google/protobuf)
            ],
        )
        .expect("protoc failed");
}
