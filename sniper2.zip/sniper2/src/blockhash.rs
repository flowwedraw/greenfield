//! Модуль для управления «горячим» blockhash.
//!
//! Для ускорения отправки транзакций на Solana необходимо иметь свежий
//! blockhash, который действителен ещё некоторое время. Blockhash сохраняется
//! в кэше и периодически обновляется, чтобы минимизировать задержки.
//! Согласно документации Helius, блокхэши действуют примерно 60–90 секунд,
//! поэтому обновление раз в 20 секунд обычно достаточно.

use std::sync::Arc;
use tokio::sync::RwLock;
use tokio::time::{interval, Duration};
use log::{debug, warn};

use crate::helius::{HeliusClient, LatestBlockhash};

/// Кэш blockhash с информацией о том, когда он перестанет быть валидным.
pub struct BlockhashCache {
    /// Текущий blockhash.
    blockhash: RwLock<String>,
    /// Высота блока, до которой blockhash остаётся валидным.
    last_valid_block_height: RwLock<u64>,
}

impl BlockhashCache {
    /// Создаёт новый пустой кэш. Изначально blockhash пустой и height = 0.
    pub fn new() -> Arc<Self> {
        Arc::new(Self {
            blockhash: RwLock::new(String::new()),
            last_valid_block_height: RwLock::new(0),
        })
    }

    /// Запускает периодическое обновление blockhash. Каждые `interval_secs`
    /// секунд будет выполняться вызов `get_latest_blockhash` у клиента Helius,
    /// после чего новые значения будут сохранены. Запуск производится в
    /// отдельной задаче, поэтому метод возвращает немедленно.
    pub fn start_refresh(self: Arc<Self>, helius: Arc<HeliusClient>, interval_secs: u64) {
        let period = Duration::from_secs(interval_secs); // ← не затеняем функцию `interval`
        let cache = Arc::clone(&self);
        tokio::spawn(async move {
            let mut ticker = interval(period);
            loop {
                ticker.tick().await;
                match helius.get_latest_blockhash().await {
                    Ok(LatestBlockhash {
                        blockhash,
                        last_valid_block_height,
                    }) => {
                        {
                            let mut h = cache.blockhash.write().await;
                            *h = blockhash.clone();
                        }
                        {
                            let mut bh = cache.last_valid_block_height.write().await;
                            *bh = last_valid_block_height;
                        }
                        debug!(
                            "Обновлён hot blockhash: {} (valid до высоты {})",
                            blockhash, last_valid_block_height
                        );
                    }
                    Err(e) => {
                        warn!("Ошибка обновления blockhash: {}", e);
                    }
                }
            }
        });
    }

    /// Возвращает текущий blockhash и максимально допустимую высоту блока.
    pub async fn get(&self) -> (String, u64) {
        let hash = self.blockhash.read().await.clone();
        let height = *self.last_valid_block_height.read().await;
        (hash, height)
    }
}
