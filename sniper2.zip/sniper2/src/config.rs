//! Загрузка и представление конфигурации из JSON-файла.

use serde::Deserialize;
use std::fs;

/// Структура конфигурации, соответствующая полям в JSON.
#[derive(Deserialize, Debug, Clone)]
pub struct Config {
    /// Тестовый режим
    pub test_mode: Option<bool>,

    // Telegram
    pub telegram_api_id: i32,
    pub telegram_api_hash: String,
    pub telegram_session_path: String,
    pub channels: Vec<String>,

    // Helius / Solana
    pub helius_api_key: String,
    pub solana_rpc_url: String,

    // Keypair
    pub keypair_path: String,

    /// Минимальная ликвидность пула в $
    pub min_liquidity: u64,

    /// Максимальная сумма входа в **SOL** (можно дробное, напр. 0.04)
    pub max_input_amount: f64,

    /// TP/SL и прочее
    pub take_profit: f64,
    pub stop_loss: f64,
    pub timeout_seconds: u64,
    pub poll_interval_seconds: u64,
    pub blockhash_refresh_interval_seconds: u64,

    /// (Опционально) вложенный блок настроек Jito
    #[serde(default)]
    pub jito: Option<JitoCfg>,

    /// (Опционально) белый список tip-аккаунтов Jito на верхнем уровне
    /// Оставляем поле, потому что `main.rs` к нему обращается как к полю.
    #[serde(default)]
    pub jito_tip_accounts: Option<Vec<String>>,

    /// (Опционально) минимальный допустимый коэффициент возврата при зеркальной продаже.
    /// Используется для фильтрации honeypot‑токенов: если ratio (sell_out / buy_in)
    /// меньше этого значения, считаем токен подозрительным. Значение должно быть в диапазоне 0.0–1.0.
    /// Если `None` — используется значение по умолчанию `0.005` (0.5%).
    #[serde(default)]
    pub min_back_ratio: Option<f64>,

    /// (Опционально) максимальный допустимый price impact при покупке.
    /// Если `priceImpactPct` маршрута превышает это значение, бот пропускает сделку.
    /// Значение задаётся как дробь: 0.90 означает 90%. Если `None` — используется
    /// значение по умолчанию `0.90` (90%).
    #[serde(default)]
    pub max_price_impact: Option<f64>,

    /// (Опционально) допуски проскальзывания для покупки, в базисных пунктах (bps).
    /// По умолчанию используется 1000 (10%).
    #[serde(default)]
    pub buy_slippage_bps: Option<u16>,

    /// (Опционально) допуски проскальзывания для продажи, в базисных пунктах (bps).
    /// По умолчанию используется 800 (8%).
    #[serde(default)]
    pub sell_slippage_bps: Option<u16>,

    /// (Опционально) флаг, разрешающий фильтр дубликатов токенов.
    /// Если true (по умолчанию), бот пропускает повторные сообщения с одним и тем же mint,
    /// пока он находится в кэше dedup. Если false, дублирующиеся mint'ы будут
    /// приниматься и бот сможет купить один и тот же токен несколько раз.
    #[serde(default)]
    pub dedup_tokens: Option<bool>,

    /// (Опционально) использовать ли существующий баланс WSOL вместо автоматического
    /// обёртывания SOL во время свопа. Если true, бот будет предполагать, что у
    /// кошелька достаточно WSOL для покупки, и будет собирать swap‑транзакцию
    /// без wrap/unwrap SOL (что экономит время). В противном случае SOL будет
    /// автоматически обёрнут/развёрнут. По умолчанию false.
    #[serde(default)]
    pub use_wsol: Option<bool>,

    /// (Опционально) строка приватного ключа (base58), используемая для восстановления keypair.
    /// Если указана, ключ будет использоваться при загрузке в Signer вместо генерации новой пары.
    #[serde(default)]
    pub secret_key: Option<String>,

    /// (Опционально) количество попыток продажи. Значение по умолчанию — 6.
    #[serde(default)]
    pub sell_retries: Option<u32>,

    /// (Опционально) количество попыток закрытия ATA. Значение по умолчанию — 6.
    #[serde(default)]
    pub close_retries: Option<u32>,

    /// (Опционально) сумма приоритизации для swap‑транзакций (лампорты).
    /// Используется в Jupiter API для повышения вероятности включения транзакций.
    /// По умолчанию 0 (без приоритизации).
    #[serde(default)]
    pub prioritization_fee_lamports: Option<u64>,

    /// (Опционально) сумма чаевых для Jito (лампорты). Передаётся в send_bundle.
    /// Значение по умолчанию — 15_000_000 (0.015 SOL).
    #[serde(default)]
    pub jito_tip_lamports: Option<u64>,

    /// (Опционально) максимальный backlog сообщений для Telegram‑канала.
    /// Это число определяет, сколько последних сообщений бот читает на каждом цикле.
    /// Если rate‑limit Telegram увеличится, значение можно уменьшить; по умолчанию 20.
    #[serde(default)]
    pub max_backlog: Option<usize>,

    /// (Опционально) источник цены для оценки позиции. Возможные значения:
    /// "jupiter" (по умолчанию), "helius". Значение регистро‑независимое.
    #[serde(default)]
    pub price_source: Option<String>,

    /// (Опционально) флаг, указывающий, сжигать ли токены при неудачной продаже.
    /// Если false (по умолчанию), бот оставляет позицию и пытается продать позже.
    #[serde(default)]
    pub burn_on_failure: Option<bool>,

    /// (Опционально) список адресов токенов, которые бот должен игнорировать при входе.
    /// Если указан, бот не будет пытаться покупать или продавать эти mint‑адреса.
    /// Поле не используется напрямую в коде, но присутствует для совместимости с конфигурацией.
    #[serde(default)]
    pub ignore_list: Option<Vec<String>>,
}

/// Доп. настройки Jito.
#[derive(Deserialize, Debug, Clone, Default)]
pub struct JitoCfg {
    pub http_url: Option<String>,          // напр., https://mainnet.block-engine.jito.wtf/api/v1
    pub grpc_url: Option<String>,          // напр., https://mainnet.block-engine.jito.wtf
    pub max_retries: Option<u32>,          // кол-во ретраев getTipAccounts
    pub retry_backoff_ms: Option<u64>,     // базовая задержка между ретраями
    pub tip_accounts: Option<Vec<String>>, // альтернативный список tip-аккаунтов (вложенный)
}

impl Config {
    /// Загружает конфигурацию из указанного файла.
    pub fn from_file(path: &str) -> anyhow::Result<Self> {
        let data = fs::read_to_string(path)?;
        let cfg: Self = serde_json::from_str(&data)?;
        Ok(cfg)
    }

    // ---------- Геттеры, которые ожидает main.rs ----------
    /// HTTP-эндпоинт Jito (Block Engine). Значение по умолчанию — mainnet.
    pub fn jito_http(&self) -> &str {
        self.jito
            .as_ref()
            .and_then(|j| j.http_url.as_deref())
            .unwrap_or("https://mainnet.block-engine.jito.wtf/api/v1")
    }

    /// gRPC-эндпоинт Jito (SearcherService). Значение по умолчанию — mainnet.
    pub fn jito_grpc(&self) -> &str {
        self.jito
            .as_ref()
            .and_then(|j| j.grpc_url.as_deref())
            .unwrap_or("https://mainnet.block-engine.jito.wtf")
    }

    /// Максимум ретраев при получении tip-аккаунтов.
    pub fn jito_max_retries(&self) -> u32 {
        // По умолчанию увеличиваем число попыток до 10, чтобы переждать сетевую перегрузку Jito.
        self.jito
            .as_ref()
            .and_then(|j| j.max_retries)
            .unwrap_or(10)
    }

    /// Базовая задержка между ретраями (мс) при получении tip-аккаунтов.
    pub fn jito_retry_backoff_ms(&self) -> u64 {
        // По умолчанию базовая задержка увеличена до 500 мс для экспоненциального backoff.
        self.jito
            .as_ref()
            .and_then(|j| j.retry_backoff_ms)
            .unwrap_or(400)
    }

    /// Объединённый список tip-аккаунтов (если задан и во вложенном блоке, и на верхнем уровне —
    /// склеиваем). `main.rs` читает верхнеуровневое поле напрямую; оставим и удобный метод.
    pub fn jito_tip_accounts_all(&self) -> Option<Vec<String>> {
        let mut out: Vec<String> = Vec::new();
        if let Some(v) = self.jito_tip_accounts.as_ref() {
            out.extend(v.iter().cloned());
        }
        if let Some(j) = self.jito.as_ref() {
            if let Some(v) = j.tip_accounts.as_ref() {
                out.extend(v.iter().cloned());
            }
        }
        if out.is_empty() { None } else { Some(out) }
    }

    /// Возвращает количество попыток продажи токена.
    pub fn sell_retries(&self) -> u32 {
        // По умолчанию увеличиваем число попыток продажи до 10.
        self.sell_retries.unwrap_or(10)
    }

    /// Возвращает количество попыток закрытия ATA.
    pub fn close_retries(&self) -> u32 {
        self.close_retries.unwrap_or(6)
    }

    /// Сумма чаевых для Jito, в лампортах.
    pub fn jito_tip_lamports(&self) -> u64 {
        self.jito_tip_lamports.unwrap_or(8_000_000)
    }

    /// Сумма приоритизации для swap‑транзакций.
    pub fn prioritization_fee_lamports(&self) -> u64 {
        self.prioritization_fee_lamports.unwrap_or(0)
    }

    /// Максимальное количество сообщений для чтения из каждого Telegram‑канала за один цикл.
    pub fn max_backlog(&self) -> usize {
        self.max_backlog.unwrap_or(20)
    }

    /// Возвращает выбранный источник цен. Допустимые значения: "jupiter" или "helius".
    pub fn price_source(&self) -> &str {
        match self.price_source.as_deref() {
            Some(src) if src.eq_ignore_ascii_case("helius") => "helius",
            _ => "jupiter",
        }
    }

    /// Разрешено ли сжигание токенов при неудачной продаже.
    pub fn burn_on_failure(&self) -> bool {
        self.burn_on_failure.unwrap_or(false)
    }
}
