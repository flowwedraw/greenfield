use anyhow::Result;
use serde_json::Value;
use std::sync::Arc;

use crate::jupiter::JupiterClient;
use crate::helius::HeliusClient;

/// Источник цен для оценки стоимости токенов в USDC.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PriceSource {
    Jupiter,
    Helius,
}

impl PriceSource {
    pub fn from_str(s: &str) -> Self {
        if s.eq_ignore_ascii_case("helius") {
            PriceSource::Helius
        } else {
            PriceSource::Jupiter
        }
    }
}

/// Сервис оценки цены токена в USDC. В зависимости от источника может
/// использовать Jupiter API (по умолчанию) либо Helius Token API.
pub struct PriceService {
    source: PriceSource,
    jup: Option<JupiterClient>,
    helius: Option<Arc<HeliusClient>>,
}

impl PriceService {
    /// Создаёт новый сервис с указанным источником. Для источника "helius"
    /// требуется передать Arc<HeliusClient>, иначе будет использован Jupiter.
    pub fn new(source: PriceSource, helius_client: Option<Arc<HeliusClient>>) -> Self {
        match source {
            PriceSource::Jupiter => Self {
                source,
                jup: Some(JupiterClient::new()),
                helius: None,
            },
            PriceSource::Helius => Self {
                source,
                jup: None,
                helius: helius_client,
            },
        }
    }

    /// Оценить стоимость `amount_atoms` токенов `mint` в USDC.
    pub async fn price_usdc(&self, mint: &str, amount_atoms: u64) -> Result<f64> {
        match self.source {
            PriceSource::Jupiter => {
                // Если JupiterClient не инициализирован, создаём его лениво.
                let jup = match &self.jup {
                    Some(client) => client,
                    None => {
                        // В редком случае, если PriceService был создан с источником Helius
                        // и затем изменён на Jupiter, создаём новый клиент на лету.
                        // Это не должна быть частая ситуация.
                        // SAFETY: вызываем без мутации self.jup, потому что self
                        // объявлен как &self; поэтому создаём локальный клиент.
                        let tmp = JupiterClient::new();
                        // Запрос у временного клиента
                        return Self::query_jupiter(&tmp, mint, amount_atoms).await;
                    }
                };
                Self::query_jupiter(jup, mint, amount_atoms).await
            }
            PriceSource::Helius => {
                let helius = self
                    .helius
                    .as_ref()
                    .ok_or_else(|| anyhow::anyhow!("HeliusClient не предоставлен для PriceService"))?;
                Self::query_helius(helius, mint, amount_atoms).await
            }
        }
    }

    /// Внутренний метод: оценка цены через Jupiter.
    async fn query_jupiter(jup: &JupiterClient, mint: &str, amount_atoms: u64) -> Result<f64> {
        // Адрес USDC на Солане
        const USDC: &str = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
        let v: Value = jup
            .quote(mint, USDC, amount_atoms, 1000, None, false)
            .await?;
        let out = v["outAmount"].as_str().unwrap_or("0").parse::<u64>().unwrap_or(0);
        Ok(out as f64 / 1_000_000.0)
    }

    /// Внутренний метод: оценка цены через Helius. Метод делает запрос
    /// get_token_info и извлекает цену в USD из поля `price_info.price_per_token`.
    async fn query_helius(helius: &HeliusClient, mint: &str, amount_atoms: u64) -> Result<f64> {
        // Запрашиваем метаданные токена. Предполагается, что Helius API
        // возвращает поля token_info.decimals и token_info.price_info.price_per_token.
        let info = helius.get_token_info(mint).await?;
        // Извлекаем decimals. По умолчанию считаем 9, если не найдено.
        let decimals: u32 = info
            .get("decimals")
            .and_then(|v| v.as_u64())
            .map(|v| v as u32)
            .or_else(|| info.get("token_info").and_then(|t| t.get("decimals")).and_then(|v| v.as_u64()).map(|v| v as u32))
            .unwrap_or(9);
        // Извлекаем цену за один токен в USDC.
        let price_per_token = info
            .get("price")
            .and_then(|v| v.as_f64())
            .or_else(|| info.get("token_info").and_then(|t| t.get("price_info")).and_then(|p| p.get("price_per_token")).and_then(|v| v.as_f64()))
            .unwrap_or(0.0);
        // amount_atoms находится в минимальных единицах (atoms). Чтобы получить
        // количество токенов, делим на 10^decimals. Затем умножаем на цену.
        let tokens: f64 = (amount_atoms as f64) / 10_f64.powi(decimals as i32);
        Ok(tokens * price_per_token)
    }
}
