use anyhow::{anyhow, Result};
use log::{info, warn};
use solana_sdk::{
    hash::Hash,
    instruction::{AccountMeta, Instruction},
    message::{VersionedMessage},
    pubkey::Pubkey,
    signature::{Keypair, Signer},
    transaction::{Transaction, VersionedTransaction},
};
use std::str::FromStr;
use tokio::time::{sleep, Duration, Instant};

// Импортируем HeliusClient и LatestBlockhash из модуля helius.
use crate::helius::{HeliusClient, LatestBlockhash};
use crate::{
    jito_client::JitoClient,
    jupiter::JupiterClient,
    price::PriceService,
    state::{Position, StateStore},
};

const WSOL: &str = "So11111111111111111111111111111111111111112";

/// Структура трейдера.
pub struct Trader {
    jup: JupiterClient,
    price: PriceService,
    state: StateStore,
    pub buy_slippage_bps: u16,
    pub sell_slippage_bps: u16,
    pub prioritization_fee_lamports: u64,
    pub jito_tip_lamports: u64,
    pub use_wsol: bool,
    pub sell_retries: u32,
    pub close_retries: u32,
}

impl Trader {
    pub fn new(
        state_path: &str,
        buy_slip: u16,
        sell_slip: u16,
        prio_fee: u64,
        jito_tip: u64,
        use_wsol: bool,
        sell_retries: u32,
        close_retries: u32,
        price: PriceService,
    ) -> Result<Self> {
        Ok(Self {
            jup: JupiterClient::new(),
            price,
            state: StateStore::open(state_path)?,
            buy_slippage_bps: buy_slip,
            sell_slippage_bps: sell_slip,
            prioritization_fee_lamports: prio_fee,
            jito_tip_lamports: jito_tip,
            use_wsol,
            sell_retries,
            close_retries,
        })
    }

    /// Возвращает список открытых позиций.
    pub fn list_positions(&self) -> Result<Vec<Position>> {
        self.state.list_positions()
    }

    /// Удаляет позицию из базы.
    pub fn remove_position(&self, mint: &str) -> Result<()> {
        self.state.remove_position(mint)
    }

    /// Собирает транзакцию покупки.
    pub async fn build_buy_tx(
        &self,
        payer: &Keypair,
        mint_out: &str,
        amount_in_lamports: u64,
        force_raydium: bool,
    ) -> Result<VersionedTransaction> {
        if self.use_wsol {
            let quote = self
                .jup
                .quote(
                    WSOL,
                    mint_out,
                    amount_in_lamports,
                    self.buy_slippage_bps,
                    None,
                    force_raydium,
                )
                .await?;
            let tx = self
                .jup
                .build_swap_tx(
                    payer.pubkey(),
                    &quote,
                    false,
                    self.prioritization_fee_lamports,
                )
                .await?;
            Ok(tx)
        } else {
            self
                .jup
                .swap(
                    payer.pubkey(),
                    WSOL,
                    mint_out,
                    amount_in_lamports,
                    self.buy_slippage_bps,
                    self.prioritization_fee_lamports,
                    force_raydium,
                )
                .await
        }
    }

    /// Собирает транзакцию продажи.
    pub async fn build_sell_tx(
        &self,
        payer: &Keypair,
        mint_in: &str,
        amount_in_atoms: u64,
        force_raydium: bool,
    ) -> Result<VersionedTransaction> {
        if self.use_wsol {
            let quote = self
                .jup
                .quote(
                    mint_in,
                    WSOL,
                    amount_in_atoms,
                    self.sell_slippage_bps,
                    None,
                    force_raydium,
                )
                .await?;
            let tx = self
                .jup
                .build_swap_tx(
                    payer.pubkey(),
                    &quote,
                    false,
                    self.prioritization_fee_lamports,
                )
                .await?;
            Ok(tx)
        } else {
            self
                .jup
                .swap(
                    payer.pubkey(),
                    mint_in,
                    WSOL,
                    amount_in_atoms,
                    self.sell_slippage_bps,
                    self.prioritization_fee_lamports,
                    force_raydium,
                )
                .await
        }
    }

    /// Подписывает транзакцию.
    pub fn sign(&self, payer: &Keypair, unsigned: VersionedTransaction) -> Result<VersionedTransaction> {
        VersionedTransaction::try_new(unsigned.message, &[payer])
            .map_err(|e| anyhow!("sign failed: {:?}", e))
    }

    /// Мониторинг TP/SL: продаём или сжигаем токены.
    /// Мониторинг TP/SL: продаём или сжигаем токены.
    ///
    /// В дополнение к стандартным параметрам принимает `entry_total_lamports` —
    /// общую сумму лампортов (SOL + WSOL) перед покупкой. Эта величина
    /// используется для расчёта прибыли/убытка после продажи.
    pub async fn monitor_tp_sl(
        &self,
        payer: &Keypair,
        mint: &str,
        amount_atoms: u64,
        entry_usdc: f64,
        tp_mult: f64,
        sl_mult: f64,
        timeout_secs: u64,
        force_raydium: bool,
        jito: &mut JitoClient,
        helius: &HeliusClient,
        entry_total_lamports: u64,
        burn_on_failure: bool,
    ) -> Result<()> {
        let tp_usdc = entry_usdc * (1.0 + tp_mult);
        let sl_usdc = entry_usdc * (1.0 - sl_mult);

        // Сохраняем позицию. Здесь мы не сохраняем entry_total_lamports в базе,
        // так как состояние существует только для проверки TP/SL. Значение
        // entry_total_lamports передаётся в функцию как параметр и используется
        // далее для расчёта прибыли/убытка.
        self.state.put_position(&Position {
            mint: mint.to_string(),
            amount_atoms,
            entry_usdc,
            tp_usdc,
            sl_usdc,
            opened_at_unix: chrono::Utc::now().timestamp(),
            entry_total_lamports: Some(entry_total_lamports),
            version: Some(1),
        })?;

        let deadline = Instant::now() + Duration::from_secs(timeout_secs);
        let mut last_quote_usdc = entry_usdc;
        let mut last_q_at = Instant::now() - Duration::from_secs(1);
        let mut last_jupiter_call = Instant::now() - Duration::from_secs(1);

        loop {
            sleep(Duration::from_millis(400)).await;
            if last_q_at.elapsed() >= Duration::from_secs(1) {
                match self.price.price_usdc(mint, amount_atoms).await {
                    Ok(px) => {
                        last_quote_usdc = px;
                        last_q_at = Instant::now();
                        last_jupiter_call = Instant::now();
                    }
                    Err(e) => warn!("Ошибка получения цены для {}: {:?}", mint, e),
                }
            }

            let pct_change = if entry_usdc > 0.0 {
                ((last_quote_usdc / entry_usdc) - 1.0) * 100.0
            } else {
                0.0
            };
            info!(
                "TP/SL мониторинг {}: цена {:.4} (TP {:.4}, SL {:.4}, Δ{:+.2}%)",
                mint, last_quote_usdc, tp_usdc, sl_usdc, pct_change
            );

            if last_quote_usdc >= tp_usdc
                || last_quote_usdc <= sl_usdc
                || Instant::now() >= deadline
            {
                let elapsed = Instant::now().duration_since(last_jupiter_call);
                if elapsed < Duration::from_secs(1) {
                    sleep(Duration::from_secs(1) - elapsed).await;
                }
                let mut sell_success = false;
                // Используем экспоненциальный backoff между попытками отправить бандл.
                let mut delay_ms: u64 = 500;
                for attempt in 0..self.sell_retries {
                    match self.build_sell_tx(payer, mint, amount_atoms, force_raydium).await {
                        Ok(unsigned) => {
                            match self.sign(payer, unsigned) {
                                Ok(signed) => {
                                    if let Some(recent) = recent_blockhash(&signed) {
                                    match jito
                                        .send_bundle(
                                            vec![signed.clone()],
                                            payer,
                                            recent,
                                            self.jito_tip_lamports,
                                        )
                                        .await
                                    {
                                        Ok(_) => {
                                            sell_success = true;
                                            info!("Позиция {} успешно продана", mint);
                                            break;
                                        }
                                        Err(e) => {
                                            warn!(
                                                "Ошибка отправки продажи {} (попытка {}): {:?}",
                                                mint,
                                                attempt + 1,
                                                e
                                            );
                                            // Отдыхаем с экспоненциальным ростом задержки.
                                            tokio::time::sleep(Duration::from_millis(delay_ms)).await;
                                            // Увеличиваем задержку, но не более 8 секунд.
                                            delay_ms = (delay_ms * 2).min(8000);
                                        }
                                    }
                                    } else {
                                        warn!("Нет recent_blockhash для сделки {}", mint);
                                    }
                                }
                                Err(e) => {
                                    warn!("Не удалось подписать продажу {}: {:?}", mint, e);
                                }
                            }
                        }
                        Err(e) => {
                            warn!(
                                "build_sell_tx ошибка (попытка {}): {:?}",
                                attempt + 1,
                                e
                            );
                            tokio::time::sleep(Duration::from_millis(delay_ms)).await;
                            delay_ms = (delay_ms * 2).min(8000);
                        }
                    }
                }
                if sell_success {
                    // Закрываем ATA для токена, если это не WSOL. Врапнутый SOL оставляем нетронутым.
                    if mint != WSOL {
                        if let Ok(mint_pk) = Pubkey::from_str(mint) {
                            match self.close_ata(helius, payer, &mint_pk, jito).await {
                                Ok(_) => info!("ATA для {} закрыт", mint),
                                Err(e) => warn!("Не удалось закрыть ATA {}: {:?}", mint, e),
                            }
                        }
                    }
                    // Удаляем позицию из базы независимо от закрытия ATA.
                    let _ = self.state.remove_position(mint);
                    // Получаем финальный баланс кошелька (SOL + WSOL) после сделки.
                    let wallet = payer.pubkey().to_string();
                    // Получаем балансы SOL и WSOL после продажи. Если возникла ошибка — используем 0.
                    let sol_after: u64 = match helius.get_sol_balance(&wallet).await {
                        Ok(v) => v,
                        Err(e) => {
                            warn!("Не удалось получить баланс SOL после продажи: {:?}", e);
                            0_u64
                        }
                    };
                    let wsol_after: u64 = match helius.get_token_balance(&wallet, WSOL).await {
                        Ok(v) => v,
                        Err(e) => {
                            warn!("Не удалось получить баланс WSOL после продажи: {:?}", e);
                            0_u64
                        }
                    };
                    let total_after = sol_after.saturating_add(wsol_after);
                    let diff: i128 = total_after as i128 - entry_total_lamports as i128;
                    let diff_sol = (diff as f64) / 1_000_000_000.0;
                    let fee_sol = (self.prioritization_fee_lamports as f64) / 1_000_000_000.0;
                    let tip_sol = (self.jito_tip_lamports as f64) / 1_000_000_000.0;
                    info!(
                        "Баланс после продажи: SOL {:.9}, WSOL {:.9}, всего {:.9}",
                        sol_after as f64 / 1_000_000_000.0,
                        wsol_after as f64 / 1_000_000_000.0,
                        total_after as f64 / 1_000_000_000.0
                    );
                    info!(
                        "Прибыль/убыток: {:+.9} SOL; комиссия fee {:.9} SOL; tip {:.9} SOL",
                        diff_sol,
                        fee_sol,
                        tip_sol
                    );
                } else {
                    // Если продажа не удалась и сжигание разрешено, выполняем burn.
                    if burn_on_failure {
                        // Не пытаемся сжечь WSOL: врапнутая SOL остаётся в кошельке.
                        if mint != WSOL {
                            if let Ok(mint_pk) = Pubkey::from_str(mint) {
                                match self.burn_and_close_ata(helius, payer, &mint_pk, jito).await {
                                    Ok(_) => {
                                        info!("Токен {} сожжён, ATA закрыт", mint);
                                        let _ = self.state.remove_position(mint);
                                        // Получаем балансы SOL и WSOL после операции burn.
                                        let wallet = payer.pubkey().to_string();
                                        let sol_after: u64 = match helius.get_sol_balance(&wallet).await {
                                            Ok(v) => v,
                                            Err(e) => {
                                                warn!(
                                                    "Не удалось получить баланс SOL после сжигания: {:?}",
                                                    e
                                                );
                                                0_u64
                                            }
                                        };
                                        let wsol_after: u64 = match helius.get_token_balance(&wallet, WSOL).await {
                                            Ok(v) => v,
                                            Err(e) => {
                                                warn!(
                                                    "Не удалось получить баланс WSOL после сжигания: {:?}",
                                                    e
                                                );
                                                0_u64
                                            }
                                        };
                                        let total_after = sol_after.saturating_add(wsol_after);
                                        let diff: i128 = total_after as i128 - entry_total_lamports as i128;
                                        let diff_sol = (diff as f64) / 1_000_000_000.0;
                                        let fee_sol = (self.prioritization_fee_lamports as f64) / 1_000_000_000.0;
                                        let tip_sol = (self.jito_tip_lamports as f64) / 1_000_000_000.0;
                                        info!(
                                            "Баланс после burn: SOL {:.9}, WSOL {:.9}, всего {:.9}",
                                            sol_after as f64 / 1_000_000_000.0,
                                            wsol_after as f64 / 1_000_000_000.0,
                                            total_after as f64 / 1_000_000_000.0
                                        );
                                        info!(
                                            "Прибыль/убыток: {:+.9} SOL; комиссия fee {:.9} SOL; tip {:.9} SOL",
                                            diff_sol,
                                            fee_sol,
                                            tip_sol
                                        );
                                    }
                                    Err(e) => {
                                        warn!(
                                            "Не удалось сжечь и закрыть ATA {}: {:?}",
                                            mint,
                                            e
                                        );
                                    }
                                }
                            }
                        } else {
                            // Нельзя сжигать WSOL; сохраняем позицию.
                            warn!(
                                "Не удалось продать {} и сжечь нельзя, поскольку это WSOL. Позиция сохраняется.",
                                mint
                            );
                        }
                    } else {
                        // Если сжигание запрещено, просто оставляем позицию открытой.
                        warn!(
                            "Продажа {} не удалась после {} попыток. Позиция сохраняется для повторной попытки.",
                            mint,
                            self.sell_retries
                        );
                    }
                }
                break;
            }
        }
        Ok(())
    }

    /// Сжигает остаток токенов и закрывает ATA.
    pub async fn burn_and_close_ata(
        &self,
        helius: &HeliusClient,
        payer: &Keypair,
        mint: &Pubkey,
        jito: &mut JitoClient,
    ) -> Result<()> {
        let token_programs = [
            // Классическая SPL Token программа
            "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
            // «Token-2022» версия SPL Token
            "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb",
            // Token22 (токен программы) — поддерживает расширения
            "Token221111111111111111111111111111111111",
        ];
        let ata_program_id = Pubkey::from_str("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL")?;
        let balance = helius
            .get_token_balance(&payer.pubkey().to_string(), &mint.to_string())
            .await?;
        if balance == 0 {
            return Ok(());
        }
        for program_str in token_programs.iter() {
            let program_id = match Pubkey::from_str(program_str) {
                Ok(pk) => pk,
                Err(_) => continue,
            };
            let owner_pub = payer.pubkey();
            let (ata, _) = Pubkey::find_program_address(
                &[owner_pub.as_ref(), program_id.as_ref(), mint.as_ref()],
                &ata_program_id,
            );
            let mut data = vec![8u8];
            data.extend_from_slice(&balance.to_le_bytes());
            for attempt in 0..self.close_retries {
                let LatestBlockhash { blockhash, .. } = helius.get_latest_blockhash().await?;
                let bh = Hash::from_str(&blockhash)?;
                let ix = Instruction {
                    program_id,
                    accounts: vec![
                        AccountMeta::new(ata, false),
                        AccountMeta::new(*mint, false),
                        AccountMeta::new_readonly(payer.pubkey(), true),
                    ],
                    data: data.clone(),
                };
                let mut burn_tx = Transaction::new_with_payer(&[ix], Some(&payer.pubkey()));
                burn_tx.sign(&[payer], bh);
                let vtx = VersionedTransaction::from(burn_tx);
                match jito
                    .send_bundle(vec![vtx], payer, bh, self.jito_tip_lamports)
                    .await
                {
                    Ok(_) => {
                        // After burn close
                        if let Err(e) = self.close_ata(helius, payer, mint, jito).await {
                            warn!("Burn ok, но close_ata ошибкой: {:?}", e);
                        }
                        return Ok(());
                    }
                    Err(e) => {
                        warn!("Burn ошибка (попытка {}) для {:?}: {:?}", attempt + 1, mint, e);
                        sleep(Duration::from_secs(1)).await;
                    }
                }
            }
        }
        Err(anyhow!("Не удалось сжечь токены для {:?}", mint))
    }

    /// Закрывает ATA.
    pub async fn close_ata(
        &self,
        helius: &HeliusClient,
        payer: &Keypair,
        mint: &Pubkey,
        jito: &mut JitoClient,
    ) -> Result<()> {
        let token_programs = [
            // Классическая SPL Token программа
            "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
            // «Token-2022» версия SPL Token
            "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb",
            // Token22 (токен программы) — поддерживает расширения
            "Token221111111111111111111111111111111111",
        ];
        let ata_program_id = Pubkey::from_str("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL")?;
        for program_str in token_programs.iter() {
            let program_id = match Pubkey::from_str(program_str) {
                Ok(pk) => pk,
                Err(_) => continue,
            };
            let owner_pub = payer.pubkey();
            let (ata, _) = Pubkey::find_program_address(
                &[owner_pub.as_ref(), program_id.as_ref(), mint.as_ref()],
                &ata_program_id,
            );
            for attempt in 0..self.close_retries {
                let LatestBlockhash { blockhash, .. } = helius.get_latest_blockhash().await?;
                let bh = Hash::from_str(&blockhash)?;
                let ix = Instruction {
                    program_id,
                    accounts: vec![
                        AccountMeta::new(ata, false),
                        AccountMeta::new(payer.pubkey(), false),
                        AccountMeta::new_readonly(payer.pubkey(), true),
                    ],
                    data: vec![9u8],
                };
                let mut tx = Transaction::new_with_payer(&[ix], Some(&payer.pubkey()));
                tx.sign(&[payer], bh);
                let vtx = VersionedTransaction::from(tx);
                match jito
                    .send_bundle(vec![vtx], payer, bh, self.jito_tip_lamports)
                    .await
                {
                    Ok(_) => {
                        return Ok(());
                    }
                    Err(e) => {
                        warn!(
                            "close_ata ошибка (попытка {}) для {:?}: {:?}",
                            attempt + 1,
                            mint,
                            e
                        );
                        sleep(Duration::from_secs(1)).await;
                    }
                }
            }
        }
        Err(anyhow!("Не удалось закрыть ATA для {:?}", mint))
    }
}

/// Возвращает recent_blockhash из VersionedTransaction.
pub fn recent_blockhash(tx: &VersionedTransaction) -> Option<Hash> {
    match &tx.message {
        VersionedMessage::Legacy(m) => Some(m.recent_blockhash),
        VersionedMessage::V0(m) => Some(m.recent_blockhash),
    }
}
