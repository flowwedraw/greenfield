use anyhow::Result;
use serde::{Deserialize, Serialize};
use sled::Db;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Position {
    pub mint: String,
    pub amount_atoms: u64,
    pub entry_usdc: f64,
    pub tp_usdc: f64,
    pub sl_usdc: f64,
    pub opened_at_unix: i64,
    /// (Опционально) общий баланс лампортов (SOL + WSOL) перед покупкой. Используется для расчёта PnL.
    #[serde(default)]
    pub entry_total_lamports: Option<u64>,
    /// Версия записи. Используется для возможных миграций схемы в будущем.
    #[serde(default)]
    pub version: Option<u32>,
}

pub struct StateStore { db: Db }

impl StateStore {
    /// Открыть или создать хранилище по пути `path`. В случае повреждения базы данных
    /// (например, из-за некорректного завершения программы) пытается удалить
    /// повреждённые файлы и создаёт новую базу. Это предотвращает ошибки типа
    /// `unexpected corruption encountered in storage snapshot file` при запуске.
    pub fn open(path: &str) -> Result<Self> {
        match sled::open(path) {
            Ok(db) => Ok(Self { db }),
            Err(e) => {
                // Попытаемся обработать повреждение базы: удаляем каталог/файл и создаём заново
                eprintln!(
                    "[StateStore] sled open error, пробуем восстановиться: {}", e
                );
                // Удаляем как папку, так и файл (если есть)
                let _ = std::fs::remove_dir_all(path);
                let _ = std::fs::remove_file(path);
                // Повторное открытие создаст новую пустую базу
                let db = sled::open(path)?;
                Ok(Self { db })
            }
        }
    }

    pub fn put_position(&self, p: &Position) -> Result<()> {
        let key = format!("pos:{}", p.mint);
        let val = bincode::serialize(p)?;
        self.db.insert(key.as_bytes(), val)?;
        self.db.flush()?; Ok(())
    }

    pub fn get_position(&self, mint: &str) -> Result<Option<Position>> {
        let key = format!("pos:{}", mint);
        let Some(ivec) = self.db.get(key.as_bytes())? else { return Ok(None) };
        let p: Position = bincode::deserialize::<Position>(&ivec)?;
        Ok(Some(p))
    }

    pub fn remove_position(&self, mint: &str) -> Result<()> {
        let key = format!("pos:{}", mint);
        self.db.remove(key.as_bytes())?; self.db.flush()?; Ok(())
    }

    /// Получить список всех открытых позиций, сохранённых в базе. Метод итерирует
    /// по ключам с префиксом `pos:` и десериализует значения в `Position`.
    pub fn list_positions(&self) -> Result<Vec<Position>> {
        let mut out = Vec::new();
        // Ключи позиций начинаются с префикса "pos:".
        for item in self.db.scan_prefix(b"pos:") {
            let (_key, val) = item?;
            let p: Position = bincode::deserialize::<Position>(&val)?;
            out.push(p);
        }
        Ok(out)
    }
}
