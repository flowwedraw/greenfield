//! Проверка ликвидности токена через Helius и Pumpswap.
//!
//! Этот модуль предоставляет удобный способ проверить, существует ли пул
//! ликвидности для заданного токена и какова его приблизительная
//! ликвидность в USD. В отличие от простого запроса через `HeliusClient`,
//! здесь дополнительно возвращается адрес пула и объём торгов за 24 часа.

use anyhow::{Context, Result};
use reqwest::Client;
use serde_json::Value;

/// Результат проверки ликвидности.
#[derive(Debug)]
pub struct LiquidityCheckResult {
    /// Существует ли пул и есть ли в нём ликвидность.
    pub is_liquid: bool,
    /// Ликвидность в долларах США, если доступна.
    pub liquidity_usd: f64,
    /// Адрес пула ликвидности, если он найден.
    pub pool_address: Option<String>,
    /// Суточный объём торгов, если предоставлен Pumpswap.
    pub volume_24h: Option<f64>,
}

/// Проверщик ликвидности, который обращается к Helius и Pumpswap.
pub struct LiquidityChecker {
    client: Client,
    helius_api_key: String,
}

impl LiquidityChecker {
    /// Создаёт новый проверщик с указанным API‑ключом Helius.
    pub fn new(helius_api_key: String) -> Self {
        Self {
            client: Client::new(),
            helius_api_key,
        }
    }

    /// Проверяет ликвидность токена по его mint‑адресу.
    ///
    /// Делает POST‑запрос к Helius для получения метаданных и GET‑запрос
    /// к Pumpswap для получения статистики пула. Возвращает структуру
    /// `LiquidityCheckResult` с флагом ликвидности, объёмом, адресом пула
    /// и суточным объёмом.
    pub async fn check(&self, mint: &str) -> Result<LiquidityCheckResult> {
        // Запрашиваем метаданные токена у Helius, чтобы узнать адрес пула.
        let helius_url = format!(
            "https://api.helius.xyz/v0/token-metadata?api-key={}",
            self.helius_api_key
        );
        let helius_resp: Value = self
            .client
            .post(&helius_url)
            .json(&serde_json::json!({ "mint": mint }))
            .send()
            .await
            .context("Не удалось выполнить запрос к Helius")?
            .json()
            .await
            .context("Не удалось разобрать ответ Helius как JSON")?;

        let pool_address = helius_resp
            .get("onChain")
            .and_then(|v| v.get("pools"))
            .and_then(|p| p.get(0))
            .and_then(|p| p.get("id"))
            .and_then(|v| v.as_str())
            .map(|s| s.to_string());

        // Запрашиваем статистику по пулу у Pumpswap. По mint‑адресу выдают
        // ликвидность и объём торгов. В случае ошибки значения останутся нулевыми.
        let pump_url = format!("https://api.pumpswap.io/v1/pools/{mint}");
        let pump_resp: Value = self
            .client
            .get(&pump_url)
            .send()
            .await
            .context("Не удалось выполнить запрос к Pumpswap")?
            .json()
            .await
            .context("Не удалось разобрать ответ Pumpswap как JSON")?;

        let liquidity_usd = pump_resp
            .get("liquidityUsd")
            .and_then(|v| v.as_f64())
            .unwrap_or(0.0);
        let volume_24h = pump_resp.get("volume24h").and_then(|v| v.as_f64());

        // Пул считается ликвидным, если адрес найден и объём > 0.
        let is_liquid = pool_address.is_some() && liquidity_usd > 0.0;

        Ok(LiquidityCheckResult {
            is_liquid,
            liquidity_usd,
            pool_address,
            volume_24h,
        })
    }
}
