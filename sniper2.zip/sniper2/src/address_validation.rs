use anyhow::{Context, Result};
use solana_sdk::pubkey::Pubkey;
use std::str::FromStr;

/// Парсим base58 строку в Pubkey. Ошибка — если строка невалидна.
pub fn parse_pubkey(s: &str) -> Result<Pubkey> {
    let pk = Pubkey::from_str(s).context("invalid pubkey base58")?;
    Ok(pk)
}

/// Mint «валиден», если корректно парсится. Глубокую проверку делаем отдельно (через Helius/Jupiter).
pub fn validate_mint(s: &str) -> Result<Pubkey> { parse_pubkey(s) }
