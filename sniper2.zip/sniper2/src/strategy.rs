#![allow(dead_code)]
pub struct Position {
    pub token: String,
    pub amount: u64,
    pub entry_price: f64,
    pub take_profit: f64,
    pub stop_loss: f64,
}
use crate::liquidity_checker::LiquidityChecker;

pub async fn execute() -> anyhow::Result<()> {
    let checker = LiquidityChecker::new("ВАШ_HELIUS_API_KEY".to_string());
    let token = "TOKEN_MINT_ADDRESS";
    let result = checker.check(token).await?;
    if result.is_liquid {
        println!("Токен {} ликвиден на сумму {} USD", token, result.liquidity_usd);
        // здесь можно вызывать swap, signer и т. д.
    } else {
        println!("Токен {} не прошёл проверку ликвидности", token);
    }
    Ok(())
}