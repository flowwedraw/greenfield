//! Модуль для построения и отправки транзакций обмена.
//!
//! Сейчас `build_swap_tx` строит **фиктивную** транзакцию перевода 0.001 SOL
//! самому себе (fee_payer -> fee_payer). Это заглушка вместо реального swap.
//! `send_transaction` — **реальная отправка** через JSON-RPC `sendTransaction`
//! (base64 сериализация), чтобы можно было тестировать боевой пайплайн.

use log::debug;
use anyhow::{Result, anyhow};
use base64::{engine::general_purpose::STANDARD, Engine as _};
use serde_json::json;

use solana_sdk::{
    hash::Hash,
    instruction::Instruction,
    message::Message,
    pubkey::Pubkey,
    system_instruction,
    transaction::Transaction,
};

/// Клиент для работы с обменами на DEX.
pub struct SwapClient {
    rpc_url: String,
}

impl SwapClient {
    /// Инициализация клиента с URL RPC-нодой Solana.
    pub fn new(rpc_url: &str) -> Self {
        Self { rpc_url: rpc_url.to_string() }
    }

    /// Строит **фиктивную** транзакцию (перевод 0.001 SOL самому себе).
    /// В реальном коде здесь нужно формировать swap-инструкции Jupiter/PumpSwap.
    pub fn build_swap_tx(
        &self,
        token_address: &str,
        _amount: f64,
        fee_payer: Pubkey,
        recent_blockhash: &Hash,
    ) -> Result<Transaction> {
        debug!(
            "build_swap_tx: адрес={}, сумма(фиктивно)={}, payer={}",
            token_address, 1_000_000u64, fee_payer
        );

        let lamports = 1_000_000u64; // 0.001 SOL
        let ix: Instruction = system_instruction::transfer(&fee_payer, &fee_payer, lamports);

        let mut message = Message::new(&[ix], Some(&fee_payer));
        message.recent_blockhash = *recent_blockhash;

        let tx = Transaction::new_unsigned(message);
        Ok(tx)
    }

    /// Реальная отправка транзакции через JSON-RPC sendTransaction (base64).
    /// Возвращает base58 подпись.
    pub async fn send_transaction(&self, tx: &Transaction) -> Result<String> {
        debug!("send_transaction: отправка в {}", self.rpc_url);

        // 1) Сериализуем и кодируем транзакцию
        let bytes = bincode::serialize(tx)?;
        let b64 = STANDARD.encode(bytes);

        // 2) Формируем JSON-RPC запрос
        //    skipPreflight = true — быстрее для снайпинга (но осторожно в бою).
        let payload = json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "sendTransaction",
            "params": [
                b64,
                {
                    "encoding": "base64",
                    "skipPreflight": true,
                    "preflightCommitment": "processed",
                    "maxRetries": 3
                }
            ]
        });

        // 3) Шлём
        let client = reqwest::Client::new();
        let resp = client
            .post(&self.rpc_url)
            .json(&payload)
            .send()
            .await?;

        let status = resp.status();
        let text = resp.text().await?;
        debug!("RPC sendTransaction status: {status}, body: {text}");

        // 4) Разбираем ответ
        let v: serde_json::Value = serde_json::from_str(&text)
            .map_err(|e| anyhow!("RPC JSON parse error: {e}; body={text}"))?;

        if let Some(sig) = v.get("result").and_then(|r| r.as_str()) {
            if sig.is_empty() {
                return Err(anyhow!("RPC returned empty signature"));
            }
            return Ok(sig.to_string());
        }

        // Иначе — ошибка
        let err_msg = v.get("error")
            .and_then(|e| e.get("message"))
            .and_then(|m| m.as_str())
            .unwrap_or("unknown RPC error");
        Err(anyhow!("sendTransaction error: {err_msg}"))
    }
}
