//! Модуль для работы с API Helius и Pumpswap.
//!
//! Содержит методы для получения ликвидности пула, сведений о токене,
//! баланса кошелька и актуального blockhash через JSON‑RPC.

use log::debug;
use reqwest::Client;
use serde_json::Value;

/// Представление ответа getLatestBlockhash.
pub struct LatestBlockhash {
    pub blockhash: String,
    pub last_valid_block_height: u64,
}

/// Клиент для взаимодействия с Helius API и RPC‑узлом Solana.
pub struct HeliusClient {
    api_key: String,
    rpc_url: String,
    http: Client,
}

impl HeliusClient {
    pub fn new(api_key: &str, rpc_url: &str) -> Self {
        // Настраиваем HTTP‑клиент: включаем keep‑alive и небольшой пул соединений.
        let http = Client::builder()
            .pool_max_idle_per_host(10)
            .tcp_keepalive(std::time::Duration::from_secs(60))
            .build()
            .expect("failed to build reqwest client");
        Self {
            api_key: api_key.to_string(),
            rpc_url: rpc_url.to_string(),
            http,
        }
    }

    pub async fn get_pool_liquidity(&self, token_address: &str) -> anyhow::Result<u64> {
        debug!("Запрос ликвидности пула для токена: {}", token_address);
        let url = format!("https://api.pumpswap.io/v1/pools/{}", token_address);
        let resp: Value = self.http.get(&url).send().await?.json().await?;
        let liquidity_usd = resp
            .get("liquidityUsd")
            .and_then(|v| v.as_f64())
            .unwrap_or(0.0);
        Ok(liquidity_usd as u64)
    }

    pub async fn get_latest_blockhash(&self) -> anyhow::Result<LatestBlockhash> {
        let request = serde_json::json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getLatestBlockhash",
            "params": [],
        });
        let resp: Value = self
            .http
            .post(&self.rpc_url)
            .header("Content-Type", "application/json")
            .header("api-key", &self.api_key)
            .json(&request)
            .send()
            .await?
            .json()
            .await?;
        let result = resp["result"]["value"].clone();
        let blockhash = result["blockhash"]
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("Ошибка чтения blockhash"))?
            .to_string();
        let last_valid_block_height = result["lastValidBlockHeight"]
            .as_u64()
            .ok_or_else(|| anyhow::anyhow!("Ошибка чтения lastValidBlockHeight"))?;
        Ok(LatestBlockhash {
            blockhash,
            last_valid_block_height,
        })
    }

    pub async fn get_token_info(&self, token_address: &str) -> anyhow::Result<Value> {
        let url = format!("https://api.helius.xyz/v0/tokens/{}", token_address);
        let resp: Value = self.http.get(&url).send().await?.json().await?;
        Ok(resp)
    }

    /// Получить баланс конкретного токена на кошельке.
    ///
    /// Используем RPC‑метод `getTokenAccountsByOwner`, который возвращает
    /// массив токен‑аккаунтов, а поле `tokenAmount.amount` содержит сырой
    /// баланс в атомах (строка). Мы суммируем значения по всем аккаунтам.
    pub async fn get_token_balance(
        &self,
        wallet_address: &str,
        token_address: &str,
    ) -> anyhow::Result<u64> {
        let request = serde_json::json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getTokenAccountsByOwner",
            "params": [
                wallet_address,
                { "mint": token_address },
                { "encoding": "jsonParsed" }
            ]
        });
        let resp: Value = self
            .http
            .post(&self.rpc_url)
            .header("Content-Type", "application/json")
            .header("api-key", &self.api_key)
            .json(&request)
            .send()
            .await?
            .json()
            .await?;
        let mut total: u128 = 0;
        if let Some(arr) = resp
            .get("result")
            .and_then(|r| r.get("value"))
            .and_then(|v| v.as_array())
        {
            for account in arr {
                if let Some(amount_str) = account
                    .get("account")
                    .and_then(|a| a.get("data"))
                    .and_then(|d| d.get("parsed"))
                    .and_then(|p| p.get("info"))
                    .and_then(|info| info.get("tokenAmount"))
                    .and_then(|t| t.get("amount"))
                    .and_then(|a| a.as_str())
                {
                    if let Ok(amount) = amount_str.parse::<u128>() {
                        total = total.saturating_add(amount);
                    }
                }
            }
        }
        Ok(total as u64)
    }

    /// Получить список всех токен‑аккаунтов владельца.
    ///
    /// Возвращает вектор кортежей `(mint, amount)`, где `mint` — адрес токена,
    /// а `amount` — баланс в атомах. Используются классические SPL Token
    /// программы `Tokenkeg…` и, при наличии, программа Token22 (`Tokenz…`).
    pub async fn get_token_accounts_by_owner(
        &self,
        wallet_address: &str,
    ) -> anyhow::Result<Vec<(String, u64)>> {
        // Вспомогательная функция для одного вызова getTokenAccountsByOwner.
        async fn fetch_accounts(
            client: &Client,
            rpc_url: &str,
            api_key: &str,
            owner: &str,
            program_id: &str,
        ) -> anyhow::Result<Vec<(String, u64)>> {
            let request = serde_json::json!({
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getTokenAccountsByOwner",
                "params": [
                    owner,
                    { "programId": program_id },
                    { "encoding": "jsonParsed" }
                ]
            });
            let resp: Value = client
                .post(rpc_url)
                .header("Content-Type", "application/json")
                .header("api-key", api_key)
                .json(&request)
                .send()
                .await?
                .json()
                .await?;
            let mut result = Vec::new();
            if let Some(arr) = resp
                .get("result")
                .and_then(|r| r.get("value"))
                .and_then(|v| v.as_array())
            {
                for account in arr {
                    // parsed.info.mint
                    let mint = account
                        .get("account")
                        .and_then(|a| a.get("data"))
                        .and_then(|d| d.get("parsed"))
                        .and_then(|p| p.get("info"))
                        .and_then(|info| info.get("mint"))
                        .and_then(|m| m.as_str())
                        .map(|s| s.to_string());
                    let amount_str = account
                        .get("account")
                        .and_then(|a| a.get("data"))
                        .and_then(|d| d.get("parsed"))
                        .and_then(|p| p.get("info"))
                        .and_then(|info| info.get("tokenAmount"))
                        .and_then(|t| t.get("amount"))
                        .and_then(|a| a.as_str())
                        .map(|s| s.to_string());
                    if let (Some(mint), Some(amount_str)) = (mint, amount_str) {
                        if let Ok(amount) = amount_str.parse::<u64>() {
                            if amount > 0 {
                                result.push((mint, amount));
                            }
                        }
                    }
                }
            }
            Ok(result)
        }
        // Собираем токены из обеих программ (классический SPL и Token22).
        let mut all = Vec::new();
        let program_ids = vec![
            // классическая SPL‑программа
            "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
            // программа Token22 для расширенных токенов
            "TokenzQd6NZsE3ExKsE5R728NUoNTKqPyZT5KkZCzZh",
        ];
        for pid in program_ids {
            match fetch_accounts(&self.http, &self.rpc_url, &self.api_key, wallet_address, pid)
                .await
            {
                Ok(mut v) => {
                    all.append(&mut v);
                }
                Err(e) => {
                    // логируем, но продолжаем собирать другие
                    log::warn!("get_token_accounts_by_owner: ошибка запроса {}: {:?}", pid, e);
                }
            }
        }
        Ok(all)
    }

    /// Получить баланс в нативных SOL (лампорты) для указанного кошелька.
    ///
    /// Отправляет JSON‑RPC запрос `getBalance` и возвращает значение из поля
    /// `result.value` в ответе. В случае ошибки генерирует `anyhow::Error`.
    pub async fn get_sol_balance(&self, wallet_address: &str) -> anyhow::Result<u64> {
        let request = serde_json::json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getBalance",
            "params": [
                wallet_address
            ]
        });
        let resp: Value = self
            .http
            .post(&self.rpc_url)
            .header("Content-Type", "application/json")
            .header("api-key", &self.api_key)
            .json(&request)
            .send()
            .await?
            .json()
            .await?;
        let val = resp
            .get("result")
            .and_then(|r| r.get("value"))
            .and_then(|v| v.as_u64())
            .ok_or_else(|| anyhow::anyhow!("Ошибка чтения баланса SOL"))?;
        Ok(val)
    }
}
