use std::collections::{HashSet, VecDeque};

pub struct Dedup {
    seen: HashSet<String>,
    order: VecDeque<String>,
    cap: usize,
}

impl Dedup {
    pub fn new(cap: usize) -> Self { Self { seen: HashSet::new(), order: VecDeque::new(), cap } }

    /// Возвращает true, если key новый (ещё не видели).
    pub fn check_and_add(&mut self, key: &str) -> bool {
        if self.seen.contains(key) { return false; }
        self.seen.insert(key.to_string());
        self.order.push_back(key.to_string());
        if self.order.len() > self.cap {
            if let Some(old) = self.order.pop_front() { self.seen.remove(&old); }
        }
        true
    }
}
