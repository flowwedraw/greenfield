use anyhow::{Context, Result};
use base64::{engine::general_purpose::STANDARD, Engine as _};
use reqwest::Client;
use serde_json::{json, Value};
use solana_sdk::{pubkey::Pubkey, transaction::VersionedTransaction};

#[derive(Clone)]
pub struct JupiterClient {
    http: Client,
    base: String,
}

impl JupiterClient {
    pub fn new() -> Self {
        Self { http: Client::new(), base: "https://quote-api.jup.ag/v6".to_owned() }
    }

    /// Получить котировку. amount — в минимальных единицах input mint (лампорты для SOL/WSOL).
    pub async fn quote(
        &self,
        input_mint: &str,
        output_mint: &str,
        amount: u64,
        slippage_bps: u16,
        platforms: Option<&str>,     // напр. Some("raydium")
        only_direct_routes: bool,    // true — без агрегированных маршрутов (быстрее/детерминированнее)
    ) -> Result<Value> {
        let mut url = format!(
            "{}/quote?inputMint={}&outputMint={}&amount={}&slippageBps={}&onlyDirectRoutes={}",
            self.base, input_mint, output_mint, amount, slippage_bps, only_direct_routes
        );
        if let Some(p) = platforms {
            if !p.is_empty() { url.push_str(&format!("&platforms={}", p)); }
        }
        let v: Value = self.http.get(&url).send().await?.error_for_status()?.json().await?;
        Ok(v)
    }

    /// Собрать swap-транзакцию по ответу quote.
    /// prioritization_fee — лампорты приоритизации (Compute Budget). Можно 0, если используем только Jito tip.
    pub async fn build_swap_tx(
        &self,
        user: Pubkey,
        quote_response: &Value,
        wrap_and_unwrap_sol: bool,
        prioritization_fee: u64,
    ) -> Result<VersionedTransaction> {
        let body = json!({
            "userPublicKey": user.to_string(),
            "wrapAndUnwrapSol": wrap_and_unwrap_sol,
            "quoteResponse": quote_response,
            "prioritizationFeeLamports": prioritization_fee,
        });
        let url = format!("{}/swap", self.base);
        let v: Value = self.http.post(&url).json(&body).send().await?.error_for_status()?.json().await?;
        let b64 = v["swapTransaction"].as_str().context("swapTransaction missing")?;
        let raw = STANDARD.decode(b64).context("decode swapTransaction")?;
        let tx: VersionedTransaction = bincode::deserialize(&raw).context("deserialize VersionedTransaction")?;
        Ok(tx)
    }

    /// High-level: получить котировку и собрать транзу swap.
    pub async fn swap(
        &self,
        user: Pubkey,
        input_mint: &str,
        output_mint: &str,
        amount: u64,
        slippage_bps: u16,
        prioritization_fee: u64,
        direct_on_raydium: bool,
    ) -> Result<VersionedTransaction> {
        let quote = self
            .quote(input_mint, output_mint, amount, slippage_bps, Some("raydium"), direct_on_raydium)
            .await
            .context("quote failed")?;
        let tx = self
            .build_swap_tx(user, &quote, true, prioritization_fee)
            .await
            .context("build swap tx failed")?;
        Ok(tx)
    }
}
