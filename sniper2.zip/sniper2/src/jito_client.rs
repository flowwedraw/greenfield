use std::str::FromStr;
use std::time::SystemTime;

use anyhow::{bail, Result};
use base64::{engine::general_purpose::STANDARD, Engine as _};

pub mod bundle   { tonic::include_proto!("bundle"); }
pub mod packet   { tonic::include_proto!("packet"); }
pub mod searcher { tonic::include_proto!("searcher"); }
pub mod shared   { tonic::include_proto!("shared"); }

use bundle::Bundle;
use packet::{Meta, Packet};
use searcher::{searcher_service_client::SearcherServiceClient, SendBundleRequest};
use shared::Header;

use jito_sdk_rust::JitoJsonRpcSDK;
use prost_types::Timestamp;
use serde_json::Value;
use solana_sdk::{
    hash::Hash,
    pubkey::Pubkey,
    signature::Keypair,
    signer::Signer,
    system_instruction,
    transaction::{Transaction, VersionedTransaction},
};
use tonic::transport::Channel;
use log::{debug, info, warn};

/// Преобразовать подписанную `VersionedTransaction` в `Packet` формата Jito.
pub fn tx_to_packet(tx: &VersionedTransaction) -> Packet {
    let data = bincode::serialize(tx).expect("serialize transaction");
    Packet {
        data: data.clone(),
        meta: Some(Meta {
            size: data.len() as u64,
            addr: String::new(),
            port: 0,
            flags: None,
            sender_stake: 0,
        }),
    }
}

/// Клиент для взаимодействия с Jito Block Engine по HTTP и gRPC.
/// Без хардкода tip-адресов. При неудаче на `getTipAccounts` — просто ошибка.
pub struct JitoClient {
    http: JitoJsonRpcSDK,
    grpc: SearcherServiceClient<Channel>,
    /// Максимум попыток получения tip-аккаунта через getTipAccounts.
    max_retries: u32,
    /// Базовый backoff между попытками (мс), растёт экспоненциально (x2).
    backoff_ms: u64,
    /// Необязательный белый список tip-аккаунтов.
    tip_whitelist: Vec<Pubkey>,
    /// Время последнего запроса к Jito HTTP API (для соблюдения лимита 1 запрос/сек).
    last_call: std::time::Instant,

    /// Кэшированный tip‑аккаунт и время его получения. Если существует и не истёк TTL,
    /// используется без запроса к getTipAccounts. Это уменьшает количество
    /// HTTP‑запросов к Jito и помогает избежать 429.
    tip_cache: Option<(Pubkey, std::time::Instant)>,

    /// Время жизни записи в tip_cache. По истечении этого времени кеш сбрасывается.
    /// Можно настроить через `set_tip_cache_ttl`.
    tip_cache_ttl: std::time::Duration,
}

impl JitoClient {
    /// Базовый конструктор. Значения retry по умолчанию: 3 попытки, backoff 200мс.
    pub async fn new(http_url: &str, grpc_url: &str) -> Result<Self> {
        let http = JitoJsonRpcSDK::new(http_url, None);
        let grpc = SearcherServiceClient::connect(grpc_url.to_string()).await?;
        Ok(Self {
            http,
            grpc,
            max_retries: 3,
            backoff_ms: 200,
            tip_whitelist: Vec::new(),
            // Инициализируем last_call временем в прошлом, чтобы первый запрос прошёл сразу.
            last_call: std::time::Instant::now() - std::time::Duration::from_secs(1),
            tip_cache: None,
            tip_cache_ttl: std::time::Duration::from_secs(60),
        })
    }

    pub fn set_retry_params(&mut self, max_retries: u32, backoff_ms: u64) {
        self.max_retries = max_retries.max(1);
        self.backoff_ms = backoff_ms.max(50);
    }

    /// Установить время жизни кэшированного tip‑аккаунта. Значение по умолчанию — 60 сек.
    pub fn set_tip_cache_ttl(&mut self, secs: u64) {
        self.tip_cache_ttl = std::time::Duration::from_secs(secs.max(1));
    }

    pub fn set_tip_whitelist(&mut self, keys: &[String]) {
        self.tip_whitelist = keys.iter()
            .filter_map(|s| Pubkey::from_str(s).ok())
            .collect();
    }

    /// Случайный tip-аккаунт с retry-логикой.
    async fn pick_tip_account(&mut self) -> Result<Pubkey> {
        use std::time::Instant;
        // 1. Если задан белый список tip‑аккаунтов, используем его в первую очередь.
        //    Это позволяет избежать обращения к RPC getTipAccounts, которое может возвращать 429.
        if !self.tip_whitelist.is_empty() {
            // Если в кэше уже есть адрес и он не устарел — используем его.
            if let Some((pk, ts)) = &self.tip_cache {
                if ts.elapsed() < self.tip_cache_ttl {
                    return Ok(*pk);
                }
            }
            // Иначе берём первый адрес из whitelist. Это гарантирует отсутствие ожидания и лишних зависимостей.
            let pk = self.tip_whitelist[0];
            self.tip_cache = Some((pk, Instant::now()));
            return Ok(pk);
        }

        // 2. Если белый список пуст — пытаемся несколько раз получить адрес через Jito RPC.
        let mut delay = self.backoff_ms;
        let mut last_err: Option<anyhow::Error> = None;
        for attempt in 1..=self.max_retries {
            // Перед каждым запросом соблюдаем ограничение по частоте.
            self.wait_rate_limit().await;
            match self.http.get_random_tip_account().await {
                Ok(addr) => {
                    if let Ok(pk) = Pubkey::from_str(&addr) {
                        debug!("Получен tip-аккаунт с попытки #{attempt}: {addr}");
                        // Сохраняем в кэш
                        self.tip_cache = Some((pk, Instant::now()));
                        return Ok(pk);
                    } else {
                        last_err = Some(anyhow::anyhow!("Неверный формат tip-адреса: {addr}"));
                    }
                }
                Err(e) => {
                    last_err = Some(e);
                }
            }
            if attempt < self.max_retries {
                warn!("getTipAccounts попытка #{attempt} не удалась; ждём {delay}мс и пробуем ещё…");
                tokio::time::sleep(std::time::Duration::from_millis(delay)).await;
                delay = delay.saturating_mul(2);
            }
        }
        // Если API отвалилось и whitelist пуст — фейлимся.
        if let Some(e) = last_err {
            bail!("getTipAccounts окончательно не удалось: {e}");
        } else {
            bail!("getTipAccounts окончательно не удалось (неизвестная ошибка)");
        }
    }

    /// Сформировать и отправить бандл:
    /// - добавляет tip-перевод (payer -> tip-аккаунт) на `tip_lamports`;
    /// - ожидает, что **все переданные транзакции уже подписаны** (кроме tip).
    /// Если tip-аккаунт получить нельзя — возвращаем ошибку (никакого fallback).
    pub async fn send_bundle(
        &mut self,
        transactions: Vec<VersionedTransaction>,
        payer: &Keypair,
        recent_blockhash: Hash,
        tip_lamports: u64,
    ) -> Result<()> {
        // Сохраняем оригинальные транзакции. Они уже подписаны и будут использованы для каждой попытки
        let orig_txs = transactions;


        // 1. Попробуем отправить бандл с каждым адресом из whitelist. Чтобы избежать конфликтов заимствования
        //    (`self` будет мутабельно заимствован в `try_send_with_tip`), сначала копируем белый список в
        //    локальный вектор и проверяем его вне блока использования `self`. Это гарантирует, что
        //    borrow-checker видит завершение immutable‑заимствований перед mutable‑заимствованием.
        let tip_list = self.tip_whitelist.clone();
        if !tip_list.is_empty() {
            for tip_pk in tip_list {
                match self
                    .try_send_with_tip(&orig_txs, tip_pk, payer, recent_blockhash, tip_lamports)
                    .await
                {
                    Ok(_) => {
                        // успешная отправка — выходим
                        return Ok(());
                    }
                    Err(e) => {
                        warn!(
                            "Попытка отправки с tip {} не удалась: {:?}. Пробуем следующий адрес…",
                            tip_pk, e
                        );
                        continue;
                    }
                }
            }
        }

        // 2. Если ни один адрес из whitelist не сработал или список пуст — используем адрес от RPC.
        self.wait_rate_limit().await;
        let addr = match self.http.get_random_tip_account().await {
            Ok(a) => a,
            Err(e) => {
                bail!("get_random_tip_account failed: {:?}", e);
            }
        };
        let pk = match Pubkey::from_str(&addr) {
            Ok(p) => p,
            Err(_) => {
                bail!("Invalid tip pubkey from Jito RPC: {}", addr);
            }
        };
        match self.try_send_with_tip(&orig_txs, pk, payer, recent_blockhash, tip_lamports).await {
            Ok(_) => Ok(()),
            Err(e) => bail!("send_bundle failed with RPC tip: {:?}", e),
        }
    }

    /// Внутренняя асинхронная функция: попытка отправить бандл с указанием tip-аккаунта.
    /// Возвращает Ok(()) при успешном включении бандла, иначе Err.
    async fn try_send_with_tip(
        &mut self,
        orig_txs: &Vec<VersionedTransaction>,
        tip_pubkey: Pubkey,
        payer: &Keypair,
        recent_blockhash: Hash,
        tip_lamports: u64,
    ) -> Result<()> {
        // Создаём копию исходных транзакций и добавляем tip-транзакцию.
        let mut txs: Vec<VersionedTransaction> = orig_txs.clone();
        let ix = system_instruction::transfer(&payer.pubkey(), &tip_pubkey, tip_lamports);
        let mut tip_tx = Transaction::new_with_payer(&[ix], Some(&payer.pubkey()));
        tip_tx.sign(&[payer], recent_blockhash);
        txs.push(VersionedTransaction::from(tip_tx));

        // 1. gRPC отправка
        self.wait_rate_limit().await;
        let bundle = JitoClient::build_bundle(&txs);
        let response = match self
            .grpc
            .send_bundle(SendBundleRequest { bundle: Some(bundle.clone()) })
            .await
        {
            Ok(res) => res.into_inner(),
            Err(e) => {
                warn!("Jito gRPC send_bundle error: {:?}", e);
                return Err(anyhow::anyhow!("gRPC send failed"));
            }
        };
        let uuid = response.uuid;

        // 2. HTTP отправка для трекинга статуса
        self.wait_rate_limit().await;
        let b64_txs: Vec<String> = txs
            .iter()
            .map(|tx| {
                let data = bincode::serialize(tx).expect("serialize transaction");
                STANDARD.encode(data)
            })
            .collect();
        let params = serde_json::json!([b64_txs, { "encoding": "base64" }]);
        match self.http.send_bundle(Some(params), None).await {
            Ok(_) => {},
            Err(e) => {
                warn!("Jito HTTP send_bundle error: {:?}", e);
                return Err(anyhow::anyhow!("HTTP send failed"));
            }
        }

        // 3. Получение статуса
        self.wait_rate_limit().await;
        let status = match self.http.get_bundle_statuses(vec![uuid.clone()]).await {
            Ok(s) => s,
            Err(e) => {
                warn!("Jito HTTP get_bundle_statuses error: {:?}", e);
                return Err(anyhow::anyhow!("HTTP status failed"));
            }
        };
        log_status(&uuid, &status);
        // Проверяем, что статус содержит непустой массив value со slot и transaction
        if let Some(value) = status.get("value") {
            if let Some(arr) = value.as_array() {
                if arr.is_empty() {
                    // Если Jito вернул пустой массив value, считаем, что бандл не включён и возвращаем ошибку.
                    return Err(anyhow::anyhow!("bundle not included"));
                }
                let obj = &arr[0];
                let slot = obj.get("slot");
                let txs_v = obj.get("transactions");
                let has_slot = slot.map(|s| !s.is_null()).unwrap_or(false);
                let has_tx = txs_v
                    .and_then(|t| t.as_array())
                    .map(|a| !a.is_empty())
                    .unwrap_or(false);
                if has_slot && has_tx {
                    // Успешно: кешируем адрес и возвращаем Ok
                    self.tip_cache = Some((tip_pubkey, std::time::Instant::now()));
                    return Ok(());
                } else {
                    return Err(anyhow::anyhow!("bundle status missing slot or tx"));
                }
            } else {
                // Если значение value не массив — это может быть ошибочный ответ RPC. Считаем, что статус отсутствует.
                // В этом случае не возвращаем ошибку, а считаем отправку успешной (бандл может быть включён). Кешируем адрес.
                warn!("Jito status `value` is not array; treating as pending success");
                self.tip_cache = Some((tip_pubkey, std::time::Instant::now()));
                return Ok(());
            }
        } else {
            // Если поле `value` отсутствует, это может быть ответ `{"error":...}` из-за сетевой перегрузки.
            // Считаем отправку успешной и кешируем адрес, чтобы не дублировать бандл. Проверка факта покупки
            // будет выполнена позже на основе баланса кошелька.
            warn!("Jito status has no `value` field; treating as pending success");
            self.tip_cache = Some((tip_pubkey, std::time::Instant::now()));
            return Ok(());
        }
    }

    /// Отправить уже готовый бандл (без добавления tip здесь).
    pub async fn send_bundle_simple(&mut self, transactions: Vec<VersionedTransaction>) -> Result<String> {
        // Собираем бандл и отправляем через gRPC.
        let bundle = JitoClient::build_bundle(&transactions);
        let response = self
            .grpc
            .send_bundle(SendBundleRequest { bundle: Some(bundle.clone()) })
            .await?
            .into_inner();
        let uuid = response.uuid;

        // Ждём перед отправкой HTTP-запроса.
        self.wait_rate_limit().await;
        let b64_txs: Vec<String> = transactions
            .iter()
            .map(|tx| {
                let data = bincode::serialize(tx).expect("serialize transaction");
                STANDARD.encode(data)
            })
            .collect();
        let params = serde_json::json!([b64_txs, { "encoding": "base64" }]);
        match self.http.send_bundle(Some(params), None).await {
            Ok(_) => {},
            Err(e) => warn!("Jito HTTP send_bundle_simple error: {:?}", e),
        }
        Ok(uuid)
    }

    /// Дождаться, чтобы с последнего HTTP-запроса к Jito прошла как минимум одна секунда.
    /// Это необходимо для соблюдения лимитов Jito (1 запрос/сек).
    async fn wait_rate_limit(&mut self) {
        use std::time::{Duration, Instant};
        let now = Instant::now();
        let elapsed = now.duration_since(self.last_call);
        if elapsed < Duration::from_secs(1) {
            tokio::time::sleep(Duration::from_secs(1) - elapsed).await;
        }
        // Обновляем время последнего вызова на текущий момент.
        self.last_call = Instant::now();
    }

    /// Запросить статус бандла по UUID (через HTTP).
    pub async fn get_bundle_status(&mut self, uuid: &str) -> Result<Value> {
        // Соблюдаем лимит перед запросом статуса.
        self.wait_rate_limit().await;
        let v = self.http.get_bundle_statuses(vec![uuid.to_string()]).await?;
        Ok(v)
    }

    /// Хелпер: собрать бандл из транзакций без отправки.
    pub fn build_bundle(transactions: &[VersionedTransaction]) -> Bundle {
        let packets: Vec<Packet> = transactions.iter().map(tx_to_packet).collect();

        Bundle {
            header: Some(Header {
                ts: Some(Timestamp::from(SystemTime::now())),
            }),
            packets,
        }
    }
}

/// Аккуратно вывести ключевые поля статуса бандла в лог (через `log`).
fn log_status(uuid: &str, status: &Value) {
    // Структура `status` может быть либо полной JSON-RPC-ответом, либо только полем `result`. Поэтому
    // пробуем извлечь массив value из нескольких мест.
    let value_opt = status
        .get("result")
        .and_then(|r| r.get("value"))
        .or_else(|| status.get("value"));
    if let Some(value) = value_opt {
        if let Some(arr) = value.as_array() {
            if !arr.is_empty() {
                let obj = &arr[0];
                let slot = obj.get("slot").cloned().unwrap_or(Value::Null);
                let hash = obj
                    .get("transactions")
                    .and_then(|txs| txs.as_array())
                    .and_then(|a| a.get(0))
                    .cloned()
                    .unwrap_or(Value::Null);
                let confirmation = obj
                    .get("confirmation_status")
                    .and_then(|c| c.as_str())
                    .unwrap_or_default()
                    .to_string();
                info!(
                    "bundle result: uuid={}, slot={:?}, tx={:?}, confirmation={}",
                    uuid, slot, hash, confirmation
                );
                return;
            }
        }
    }
    // Если структура неизвестна, логируем весь статус как предупреждение.
    warn!("bundle result: uuid={}, статус в неожиданном формате: {:?}", uuid, status);
}
