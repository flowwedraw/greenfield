//! Модуль для загрузки и управления ключами подписи транзакций.
//!
//! Использует `solana_sdk` для чтения ключа из файла. В случае ошибки
//! генерирует новую пару. Предоставляет прогрев подписи, чтобы избежать
//! задержки при первом использовании.

use anyhow::{bail, Result};
use log::{info, warn};
use solana_sdk::signature::{read_keypair_file, Keypair};
use solana_sdk::signature::Signer as SolanaSigner; // трейт в скоупе
use solana_sdk::transaction::Transaction;

/// Обёртка вокруг `Keypair`, обеспечивающая создание и подпись транзакций.
pub struct Signer {
    keypair: Keypair,
}

impl Signer {
    /// Создаёт новый `Signer` из конфигурации. Сначала пытается загрузить ключ из файла
    /// `keypair_path`. Если файл недоступен или содержит некорректный формат, и
    /// передан `secret_key`, то пробует декодировать приватный ключ из base58 и
    /// восстановить `Keypair` из него. В противном случае возвращает ошибку.
    pub fn new(keypair_path: &str, secret_key: Option<&str>) -> anyhow::Result<Self> {
        use std::path::Path;
        info!("Загрузка keypair из {}", keypair_path);
        // Сначала пробуем считать keypair из файла, если он существует.
        if Path::new(keypair_path).exists() {
            match read_keypair_file(keypair_path) {
                Ok(kp) => return Ok(Self { keypair: kp }),
                Err(e) => {
                    warn!("Не удалось загрузить keypair из файла {}: {:?}", keypair_path, e);
                    // продолжаем ниже, возможно задан secret_key
                }
            }
        } else {
            warn!("Файл keypair_path {} не найден", keypair_path);
        }
        // Если файл не прочитан, пробуем secret_key
        if let Some(sk_str) = secret_key {
            use bs58;
            let bytes = bs58::decode(sk_str)
                .into_vec()
                .map_err(|e| anyhow::anyhow!("Ошибка декодирования secret_key: {e}"))?;
            if bytes.len() == 64 {
                match Keypair::from_bytes(&bytes) {
                    Ok(kp) => return Ok(Self { keypair: kp }),
                    Err(e) => bail!("Не удалось создать Keypair из secret_key: {e}"),
                }
            } else {
                bail!("secret_key имеет недопустимую длину: {} байт", bytes.len());
            }
        }
        // Ни файл, ни secret_key не заданы — возвращаем ошибку, чтобы предупредить пользователя.
        bail!("Не удалось загрузить ключевую пару: файл отсутствует или повреждён, secret_key не задан");
    }

    /// Публичный ключ текущего keypair.
    pub fn pubkey(&self) -> solana_sdk::pubkey::Pubkey {
        self.keypair.pubkey()
    }

    /// Доступ к внутреннему Keypair (для подписи VersionedTransaction, Jito-бандлов и т. п.).
    pub fn keypair(&self) -> &Keypair {
        &self.keypair
    }

    /// Подписывает транзакцию частично, используя `recent_blockhash` из сообщения.
    /// Если fee payer транзакции не совпадает с нашим — возвращаем ошибку (без паники).
    pub fn sign_transaction(&self, mut tx: Transaction) -> Result<Transaction> {
        // В legacy Message fee payer — это первый ключ.
        let my = self.keypair.pubkey();
        let fee_payer = tx
            .message
            .account_keys
            .get(0)
            .copied()
            .ok_or_else(|| anyhow::anyhow!("в сообщении пустой список account_keys"))?;

        if fee_payer != my {
            bail!("fee payer mismatch: tx={}, signer={}", fee_payer, my);
        }

        tx.partial_sign(&[&self.keypair], tx.message.recent_blockhash);
        info!("Транзакция подписана нашим keypair");
        Ok(tx)
    }

    /// Прогревает подпись, подписывая «пустую» транзакцию.
    /// Важно: fee payer должен быть равен нашему ключу, иначе `partial_sign` упадёт.
    pub fn warm_up(&self) -> Result<()> {
        use solana_sdk::{hash::Hash, message::Message, system_instruction};

        // Перевод самому себе на 0 лампортов — безопасная заглушка.
        let dummy_ix =
            system_instruction::transfer(&self.keypair.pubkey(), &self.keypair.pubkey(), 0);

        // Сообщение с fee payer = наш ключ.
        let mut message = Message::new(&[dummy_ix], Some(&self.keypair.pubkey()));
        message.recent_blockhash = Hash::new_unique();

        // Подписываем (не отправляем).
        let mut tx = Transaction::new_unsigned(message);
        tx.partial_sign(&[&self.keypair], tx.message.recent_blockhash);

        info!("Выполнено прогревание подписи (dummy-транзакция)");
        Ok(())
    }
}
