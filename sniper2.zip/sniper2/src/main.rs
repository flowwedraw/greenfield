use clap::Parser;
use env_logger::Env;
use log::{debug, info, warn};
use std::sync::Arc;
use std::time::Duration;

use crate::address_validation::validate_mint;
use crate::trader::Trader;
use crate::price::PriceService;
use solana_sdk::pubkey::Pubkey;
use std::str::FromStr;

// Сделаем модули публичными, чтобы их было видно из других модулей и двоичного файла
pub mod config;
pub mod helius;
pub mod blockhash;
pub mod signer;
pub mod swap;
pub mod telegram;
pub mod utils;
pub mod jito_client;
pub mod liquidity_checker;
pub mod strategy;
pub mod jupiter;
pub mod price;
pub mod address_validation;
pub mod state;
pub mod dedup;
pub mod trader;

#[derive(Parser)]
#[command(author, version, about, long_about = None)]
struct Args {
    #[arg(short, long)]
    config: String,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    env_logger::Builder::from_env(Env::default().default_filter_or("info")).init();

    let args = Args::parse();
    debug!("Аргументы переданы: config = {}", args.config);

    let cfg = config::Config::from_file(&args.config)?;
    info!(
        "Конфигурация загружена: min_liquidity={}, max_input_amount={}",
        cfg.min_liquidity, cfg.max_input_amount
    );

    let mut telegram = telegram::TelegramClient::new(
        cfg.telegram_api_id,
        &cfg.telegram_api_hash,
        &cfg.telegram_session_path,
        cfg.channels.clone(),
        cfg.max_backlog(),
    )
    .await?;
    info!("Telegram-клиент инициализирован");

    let helius = Arc::new(helius::HeliusClient::new(
        &cfg.helius_api_key,
        &cfg.solana_rpc_url,
    ));
    info!("Helius-клиент инициализирован");

    let _swapper = swap::SwapClient::new(&cfg.solana_rpc_url);
    info!("Swap-клиент инициализирован");

    // Создаём Signer, используя путь к ключу и дополнительный secret_key, если задан в конфигурации.
    let signer = signer::Signer::new(&cfg.keypair_path, cfg.secret_key.as_deref())?;
    info!("Signer инициализирован");
    signer.warm_up()?;

    let block_cache = blockhash::BlockhashCache::new();
    let block_cache_bg = Arc::clone(&block_cache);
    block_cache_bg.start_refresh(Arc::clone(&helius), cfg.blockhash_refresh_interval_seconds);

    let mut jito = jito_client::JitoClient::new(cfg.jito_http(), cfg.jito_grpc()).await?;
    jito.set_retry_params(cfg.jito_max_retries(), cfg.jito_retry_backoff_ms());
    if let Some(addrs) = cfg.jito_tip_accounts_all() {
        jito.set_tip_whitelist(&addrs);
    }

    let mut dedup = dedup::Dedup::new(2000);

    // Создаём сервис цен в зависимости от конфигурации
    let price_source = price::PriceSource::from_str(cfg.price_source());
    let price_service = price::PriceService::new(price_source, Some(Arc::clone(&helius)));
    // Создаём трейдера с параметрами, определёнными в конфигурации
    let trader = Trader::new(
        "bot_state.db",
        cfg.buy_slippage_bps.unwrap_or(1000),
        cfg.sell_slippage_bps.unwrap_or(800),
        cfg.prioritization_fee_lamports(),
        cfg.jito_tip_lamports(),
        // По умолчанию используем wSOL для свопов, чтобы врапнутый SOL не разворачивался.
        cfg.use_wsol.unwrap_or(true),
        cfg.sell_retries(),
        cfg.close_retries(),
        price_service,
    )?;

    // Обрабатываем старые позиции
    {
        let positions = trader.list_positions()?;
        info!("Найдено {} позиций из предыдущих запусков", positions.len());
        for pos in positions {
            info!("Обработка позиции {}: {} атомов", pos.mint, pos.amount_atoms);
            let wallet = signer.pubkey().to_string();
            match helius.get_token_balance(&wallet, &pos.mint).await {
                Ok(actual) => {
                    info!("Баланс {}: {}", pos.mint, actual);
                    if actual == 0 {
                        info!("Баланс токена {} = 0, удаляем позицию", pos.mint);
                        let _ = trader.remove_position(&pos.mint);
                        continue;
                    }
                    info!("Продаём остаток {}: {} атомов", pos.mint, actual);
                    match trader
                        .build_sell_tx(signer.keypair(), &pos.mint, actual, false)
                        .await
                    {
                        Ok(unsigned_sell) => {
                            match trader.sign(signer.keypair(), unsigned_sell) {
                                Ok(signed_sell) => {
                                    if let Some(recent) =
                                        crate::trader::recent_blockhash(&signed_sell)
                                    {
                                        match jito
                                            .send_bundle(
                                                vec![signed_sell.clone()],
                                                signer.keypair(),
                                                recent,
                                                trader.jito_tip_lamports,
                                            )
                                            .await
                                        {
                                            Ok(_) => {
                                                info!("Продажа {} отправлена", pos.mint);
                                                // Закрываем ATA только если это не WSOL.
                                                if pos.mint != "So11111111111111111111111111111111111111112" {
                                                    if let Ok(mint_pk) = Pubkey::from_str(&pos.mint) {
                                                        match trader
                                                            .close_ata(
                                                                helius.as_ref(),
                                                                signer.keypair(),
                                                                &mint_pk,
                                                                &mut jito,
                                                            )
                                                            .await
                                                        {
                                                            Ok(_) => info!("ATA для {} закрыт", pos.mint),
                                                            Err(e) => warn!("Не удалось закрыть ATA {}: {:?}", pos.mint, e),
                                                        }
                                                    }
                                                }
                                                // Удаляем позицию из state
                                                let _ = trader.remove_position(&pos.mint);
                                            }
                                            Err(e) => {
                                                warn!(
                                                    "Не удалось отправить бандл продажи для {}: {:?}. Позиция остаётся на месте для повторной попытки.",
                                                    pos.mint,
                                                    e
                                                );
                                                // Не сжигаем токены в случае ошибки: просто оставляем позицию.
                                            }
                                        }
                                    } else {
                                        warn!("Не найден recent_blockhash для сделки по {}. Позиция остаётся.", pos.mint);
                                    }
                                }
                                Err(e) => {
                                    warn!("Не удалось подписать транзакцию продажи {}: {:?}", pos.mint, e);
                                }
                            }
                        }
                        Err(e) => {
                            warn!(
                                "Не удалось собрать транзакцию продажи для {}: {:?}. Позиция остаётся для повторной попытки.",
                                pos.mint,
                                e
                            );
                            // Не сжигаем токен и не закрываем ATA: попытка будет в следующем запуске.
                        }
                    }
                }
                Err(e) => {
                    warn!("Не удалось получить баланс токена {}: {:?}. Позиция остаётся.", pos.mint, e);
                }
            }
        }
    }

    // После обработки позиций проверяем кошелёк на наличие зависших токенов.
    // Иногда в кошельке могут остаться токены из незавершённых сделок, которые не записаны в state.
    {
        let wallet = signer.pubkey().to_string();
        // Собираем перечень уже учтённых позиций, чтобы не дублировать обработку.
        let current_positions = trader.list_positions()?;
        let mut known_mints = std::collections::HashSet::new();
        for pos in &current_positions {
            known_mints.insert(pos.mint.clone());
        }
        // Запрашиваем все токен‑аккаунты пользователя (кроме WSOL).
        match helius.get_token_accounts_by_owner(&wallet).await {
            Ok(accounts) => {
                for (mint, amount) in accounts {
                    // пропускаем WSOL
                    if mint == "So11111111111111111111111111111111111111112" {
                        continue;
                    }
                    // пропускаем известные позиции из state
                    if known_mints.contains(&mint) {
                        continue;
                    }
                    info!(
                        "Обнаружен зависший токен {}: {} атомов. Попытаемся продать и закрыть ATA.",
                        mint, amount
                    );
                    // Запоминаем общий баланс до продажи (SOL + WSOL), чтобы отследить PnL
                    let sol_before: u64 = match helius.get_sol_balance(&wallet).await {
                        Ok(v) => v,
                        Err(e) => {
                            warn!(
                                "Не удалось получить баланс SOL перед продажей зависшего {}: {:?}",
                                mint, e
                            );
                            0_u64
                        }
                    };
                    let wsol_before: u64 = match helius.get_token_balance(&wallet, "So11111111111111111111111111111111111111112").await {
                        Ok(v) => v,
                        Err(e) => {
                            warn!(
                                "Не удалось получить баланс WSOL перед продажей зависшего {}: {:?}",
                                mint, e
                            );
                            0_u64
                        }
                    };
                    let entry_total = sol_before.saturating_add(wsol_before);
                    // Собираем транзакцию продажи
                    match trader.build_sell_tx(signer.keypair(), &mint, amount, false).await {
                        Ok(unsigned_sell) => {
                            match trader.sign(signer.keypair(), unsigned_sell) {
                                Ok(signed_sell) => {
                                    // Получаем recent_blockhash
                                    if let Some(recent) = crate::trader::recent_blockhash(&signed_sell) {
                                        match jito
                                            .send_bundle(
                                                vec![signed_sell.clone()],
                                                signer.keypair(),
                                                recent,
                                                trader.jito_tip_lamports,
                                            )
                                            .await
                                        {
                                            Ok(_) => {
                                                info!("Продажа зависшего {} отправлена", mint);
                                                // Закрываем ATA только если это не WSOL.
                                                if mint != "So11111111111111111111111111111111111111112" {
                                                    if let Ok(mint_pk) = Pubkey::from_str(&mint) {
                                                        match trader
                                                            .close_ata(helius.as_ref(), signer.keypair(), &mint_pk, &mut jito)
                                                            .await
                                                        {
                                                            Ok(_) => info!("ATA для {} закрыт", mint),
                                                            Err(e) => warn!("Не удалось закрыть ATA {}: {:?}", mint, e),
                                                        }
                                                    }
                                                }
                                                // Получаем баланс после продажи и выводим PnL
                                                let sol_after: u64 = match helius.get_sol_balance(&wallet).await {
                                                    Ok(v) => v,
                                                    Err(e) => {
                                                        warn!("Не удалось получить баланс SOL после продажи {}: {:?}", mint, e);
                                                        0_u64
                                                    }
                                                };
                                                let wsol_after: u64 = match helius.get_token_balance(&wallet, "So11111111111111111111111111111111111111112").await {
                                                    Ok(v) => v,
                                                    Err(e) => {
                                                        warn!("Не удалось получить баланс WSOL после продажи {}: {:?}", mint, e);
                                                        0_u64
                                                    }
                                                };
                                                let total_after = sol_after.saturating_add(wsol_after);
                                                let diff: i128 = total_after as i128 - entry_total as i128;
                                                let diff_sol = (diff as f64) / 1_000_000_000.0;
                                                let fee_sol = (trader.prioritization_fee_lamports as f64) / 1_000_000_000.0;
                                                let tip_sol = (trader.jito_tip_lamports as f64) / 1_000_000_000.0;
                                                info!(
                                                    "Баланс после продажи {}: SOL {:.9}, WSOL {:.9}, всего {:.9}",
                                                    mint,
                                                    sol_after as f64 / 1_000_000_000.0,
                                                    wsol_after as f64 / 1_000_000_000.0,
                                                    total_after as f64 / 1_000_000_000.0
                                                );
                                                info!(
                                                    "Прибыль/убыток по {}: {:+.9} SOL; fee {:.9} SOL; tip {:.9} SOL",
                                                    mint, diff_sol, fee_sol, tip_sol
                                                );
                                            }
                                            Err(e) => {
                                                warn!(
                                                    "Не удалось отправить бандл продажи зависшего {}: {:?}. Токен будет обработан позже.",
                                                    mint,
                                                    e
                                                );
                                                // Не сжигаем токен и не закрываем ATA в случае ошибки: оставляем на следующую попытку.
                                            }
                                        }
                                    } else {
                                        warn!("Не найден recent_blockhash для продажи {}. Пропускаем.", mint);
                                    }
                                }
                                Err(e) => {
                                    warn!("Не удалось подписать продажу зависшего {}: {:?}", mint, e);
                                }
                            }
                        }
                        Err(e) => {
                            warn!(
                                "Не удалось собрать транзакцию продажи для зависшего {}: {:?}. Токен будет обработан позже.",
                                mint,
                                e
                            );
                            // Не сжигаем токен и не закрываем ATA: оставляем токен для повторной попытки.
                        }
                    }
                }
            }
            Err(e) => {
                warn!("Не удалось получить список токенов кошелька: {:?}", e);
            }
        }
    }

    // Основной цикл
    loop {
        let messages = match telegram.fetch_messages().await {
            Ok(v) => v,
            Err(e) => {
                warn!("Telegram fetch_messages error: {e}. Повторим после короткой паузы…");
                tokio::time::sleep(Duration::from_secs(1)).await;
                continue;
            }
        };
        info!("Получено {} новых сообщений", messages.len());

        for msg in messages {
            debug!("Обработка сообщения: {}", msg);
            let Some(token_addr) = telegram.parse_token_address(&msg) else {
                debug!("Адрес токена не найден в сообщении");
                continue;
            };
            info!("Найден токен: {}", token_addr);

            if cfg.dedup_tokens.unwrap_or(true) {
                if !dedup.check_and_add(&token_addr) {
                    debug!("Дубль адреса, пропускаем: {}", token_addr);
                    continue;
                }
            }

            // Проверяем список игнорируемых токенов из конфигурации. Если mint находится
            // в ignore_list, бот пропускает обработку этого токена.
            if let Some(ref ignores) = cfg.ignore_list {
                if ignores.iter().any(|v| v == &token_addr) {
                    info!("Токен {} находится в ignore_list, пропускаем", token_addr);
                    continue;
                }
            }

            // Validate mint
            if let Err(e) = validate_mint(&token_addr) {
                warn!("Невалидный mint {}: {:?}", token_addr, e);
                continue;
            }

            let entry_lamports: u64 = (cfg.max_input_amount * 1_000_000_000.0).round() as u64;
            info!("entry_lamports = {}", entry_lamports);

            // Получаем котировку покупки и ликвидность (не ограничиваем Raydium)
            let jup = jupiter::JupiterClient::new();
            let quote_buy_future = jup.quote(
                "So11111111111111111111111111111111111111112",
                &token_addr,
                entry_lamports,
                trader.buy_slippage_bps,
                None,
                false,
            );
            let liquidity_future = helius.get_pool_liquidity(&token_addr);
            let (quote_buy_res, liquidity_res) = tokio::join!(quote_buy_future, liquidity_future);

            let quote_buy = match quote_buy_res {
                Ok(v) => v,
                Err(e) => {
                    warn!("Jupiter BUY quote failed for {}: {:?}", token_addr, e);
                    continue;
                }
            };

            let expected_out_atoms: u64 = quote_buy["outAmount"]
                .as_str()
                .and_then(|s| s.parse::<u64>().ok())
                .unwrap_or(0);
            if expected_out_atoms == 0 {
                warn!("Маршрут пуст (outAmount=0) для {}", token_addr);
                continue;
            }

            // Price impact
            let price_impact = quote_buy["priceImpactPct"]
                .as_f64()
                .or_else(|| quote_buy["priceImpact"].as_f64())
                .or_else(|| quote_buy["priceImpactPct"].as_str().and_then(|s| s.parse::<f64>().ok()))
                .unwrap_or(-1.0);
            if price_impact >= 0.0 {
                let max_impact = cfg.max_price_impact.unwrap_or(0.90);
                if price_impact > max_impact {
                    warn!(
                        "Слишком высокий price impact {:.2}% для {} (порог {:.2}%). Пропускаем.",
                        price_impact * 100.0,
                        token_addr,
                        max_impact * 100.0
                    );
                    continue;
                } else {
                    info!("Price impact для {} ок: {:.2}%", token_addr, price_impact * 100.0);
                }
            } else {
                info!("Price impact не предоставлен для {}, продолжаем без фильтра", token_addr);
            }

            // Liquidity check
            if let Ok(v) = liquidity_res {
                info!("Ликвидность пула {}: {}", token_addr, v);
                if v < cfg.min_liquidity {
                    warn!(
                        "Недостаточно ликвидности: {} < {} для {}",
                        v, cfg.min_liquidity, token_addr
                    );
                    continue;
                }
            } else {
                warn!(
                    "Liquidity check failed for {}: {:?}. Продолжаем.",
                    token_addr,
                    liquidity_res.unwrap_err()
                );
            }

            // Дополнительный лог: получаем сведения о пуле через LiquidityChecker
            {
                use crate::liquidity_checker::LiquidityChecker;
                let checker = LiquidityChecker::new(cfg.helius_api_key.clone());
                match checker.check(&token_addr).await {
                    Ok(res) => {
                        if let Some(pool) = res.pool_address {
                            info!(
                                "Пул для {} найден: адрес {}, ликвидность {:.2} USD, объём 24ч {:?}",
                                token_addr,
                                pool,
                                res.liquidity_usd,
                                res.volume_24h
                            );
                        } else {
                            info!(
                                "Пул для {} не найден либо неликвиден (liq {:.2} USD)",
                                token_addr,
                                res.liquidity_usd
                            );
                        }
                    }
                    Err(e) => {
                        warn!("Не удалось получить расширенную информацию о пуле {}: {:?}", token_addr, e);
                    }
                }
            }

            // Проверка SELL на небольшой сумме
            let test_sell_amount: u64 = std::cmp::max(expected_out_atoms / 20, 1_000_000);
            let quote_sell = match jup
                .quote(
                    &token_addr,
                    "So11111111111111111111111111111111111111112",
                    test_sell_amount,
                    trader.sell_slippage_bps,
                    None,
                    false,
                )
                .await
            {
                Ok(v) => v,
                Err(e) => {
                    warn!("Jupiter SELL quote failed for {}: {:?}", token_addr, e);
                    continue;
                }
            };
            let sell_out_lamports: u64 = quote_sell["outAmount"]
                .as_str()
                .and_then(|s| s.parse::<u64>().ok())
                .unwrap_or(0);
            if sell_out_lamports == 0 {
                warn!("SELL route empty (outAmount=0) for {} — вероятный honeypot. Скипаем.", token_addr);
                continue;
            }
            let expected_back_ratio = (sell_out_lamports as f64) / (entry_lamports as f64);
            let min_ratio = cfg.min_back_ratio.unwrap_or(0.005);
            if expected_back_ratio < min_ratio {
                warn!(
                    "SELL back ratio слишком низкий ({:.4}) для {} — пропускаем.",
                    expected_back_ratio, token_addr
                );
                continue;
            }

            info!(
                "BUY {} за {} лампортов WSOL (ожидаем ~{} атомов)",
                token_addr, entry_lamports, expected_out_atoms
            );

            // Получаем балансы до покупки: SOL и WSOL. Запросы выполняются параллельно,
            // чтобы уменьшить задержку. join! возвращает кортеж из двух результатов.
            let wallet_str = signer.pubkey().to_string();
            let (sol_res, wsol_res) = tokio::join!(
                helius.get_sol_balance(&wallet_str),
                helius.get_token_balance(&wallet_str, "So11111111111111111111111111111111111111112")
            );
            let bal_sol_before: u64 = match sol_res {
                Ok(v) => v,
                Err(e) => {
                    warn!("Не удалось получить баланс SOL перед покупкой: {:?}", e);
                    0
                }
            };
            let bal_wsol_before: u64 = match wsol_res {
                Ok(v) => v,
                Err(e) => {
                    warn!("Не удалось получить баланс WSOL перед покупкой: {:?}", e);
                    0
                }
            };
            let entry_total_lamports: u64 = bal_sol_before.saturating_add(bal_wsol_before);
            info!(
                "Баланс перед покупкой: SOL {:.9}, WSOL {:.9}, всего {:.9}",
                bal_sol_before as f64 / 1_000_000_000.0,
                bal_wsol_before as f64 / 1_000_000_000.0,
                entry_total_lamports as f64 / 1_000_000_000.0
            );

            // Собираем и отправляем покупку
            match trader
                .build_buy_tx(signer.keypair(), &token_addr, entry_lamports, false)
                .await
            {
                Ok(unsigned_buy) => {
                    match trader.sign(signer.keypair(), unsigned_buy) {
                        Ok(signed_buy) => {
                            if let Some(recent) = crate::trader::recent_blockhash(&signed_buy) {
                                match jito
                                    .send_bundle(
                                        vec![signed_buy.clone()],
                                        signer.keypair(),
                                        recent,
                                        trader.jito_tip_lamports,
                                    )
                                    .await
                                {
                                    Ok(_) => {
                                        info!("Bundle (BUY) отправлен через Jito для {}", token_addr);
                                        // После отправки ждём немного, чтобы транзакция была обработана, затем проверяем баланс.
                                        tokio::time::sleep(std::time::Duration::from_secs(2)).await;
                                        // Получаем балансы SOL и WSOL параллельно после покупки.
                                        let (sol_res_after, wsol_res_after) = tokio::join!(
                                            helius.get_sol_balance(&wallet_str),
                                            helius.get_token_balance(&wallet_str, "So11111111111111111111111111111111111111112")
                                        );
                                        let sol_after_buy: u64 = match sol_res_after {
                                            Ok(v) => v,
                                            Err(e) => {
                                                warn!("Не удалось получить баланс SOL после покупки: {:?}", e);
                                                0
                                            }
                                        };
                                        let wsol_after_buy: u64 = match wsol_res_after {
                                            Ok(v) => v,
                                            Err(e) => {
                                                warn!("Не удалось получить баланс WSOL после покупки: {:?}", e);
                                                0
                                            }
                                        };
                                        let total_after_buy: u64 = sol_after_buy.saturating_add(wsol_after_buy);
                                        let diff_buy: i128 = total_after_buy as i128 - entry_total_lamports as i128;
                                        let diff_buy_sol: f64 = (diff_buy as f64) / 1_000_000_000.0;
                                        info!(
                                            "Баланс после покупки: SOL {:.9}, WSOL {:.9}, всего {:.9}",
                                            sol_after_buy as f64 / 1_000_000_000.0,
                                            wsol_after_buy as f64 / 1_000_000_000.0,
                                            total_after_buy as f64 / 1_000_000_000.0
                                        );
                                        info!(
                                            "Потрачено на покупку (включая fee/tip): {:+.9} SOL",
                                            -diff_buy_sol
                                        );
                                        // Проверяем, что баланс уменьшился (diff_buy < 0). Если нет — считаем, что покупка не произошла.
                                        if diff_buy >= 0 {
                                            warn!(
                                                "Покупка {} не состоялась: баланс не уменьшился, пропускаем.",
                                                token_addr
                                            );
                                            continue;
                                        }
                                        // Цена входа в USDC (оценка WSOL → USDC)
                                        let tmp_price_service = PriceService::new(price_source, Some(Arc::clone(&helius)));
                                        let entry_usdc = match tmp_price_service
                                            .price_usdc(
                                                "So11111111111111111111111111111111111111112",
                                                entry_lamports,
                                            )
                                            .await
                                        {
                                            Ok(v) => v,
                                            Err(e) => {
                                                warn!("Не удалось получить цену WSOL в USDC: {:?}", e);
                                                0.0
                                            }
                                        };
                                        // Запускаем мониторинг TP/SL только после успешной покупки
                                        if let Err(e) = trader
                                            .monitor_tp_sl(
                                                signer.keypair(),
                                                &token_addr,
                                                expected_out_atoms,
                                                entry_usdc,
                                                cfg.take_profit,
                                                cfg.stop_loss,
                                                cfg.timeout_seconds,
                                                false,
                                                &mut jito,
                                                helius.as_ref(),
                                                entry_total_lamports,
                                                cfg.burn_on_failure(),
                                            )
                                            .await
                                        {
                                            warn!("Ошибка в monitor_tp_sl для {}: {:?}", token_addr, e);
                                        }
                                    }
                                    Err(e) => {
                                        warn!("Jito send_bundle failed: {:?}. Покупка {} пропускаем.", e, token_addr);
                                        continue;
                                    }
                                }
                            } else {
                                warn!("Нет recent_blockhash внутри buy-транзакции; покупку пропускаем.");
                                continue;
                            }
                        }
                        Err(e) => {
                            warn!("Не удалось подписать покупку {}: {:?}", token_addr, e);
                            continue;
                        }
                    }
                }
                Err(e) => {
                    warn!("build_buy_tx failed для {}: {:?}", token_addr, e);
                    continue;
                }
            }

        }

        debug!(
            "Ожидание {} секунд перед следующим циклом",
            cfg.poll_interval_seconds
        );
        tokio::time::sleep(Duration::from_secs(cfg.poll_interval_seconds)).await;
    }
}
