//! Вспомогательные функции для логики Take‑Profit и Stop‑Loss.

use log::info;
use std::time::Duration;

/// Применяет логику Take‑Profit и Stop‑Loss после таймаута. Пока это
/// просто задержка на `timeout_secs` секунд. В будущем сюда можно
/// добавить отслеживание котировок и принятие решений об оставлении или
/// завершении позиции.
pub async fn apply_take_profit_and_stop_loss(
    signature: &str,
    tp: f64,
    sl: f64,
    timeout_secs: u64,
) {
    info!(
        "Ожидание {} секунд перед применением TP/SL для {} (tp={}, sl={})",
        timeout_secs, signature, tp, sl
    );
    tokio::time::sleep(Duration::from_secs(timeout_secs)).await;
    // TODO: Реализовать логику TP/SL
}
