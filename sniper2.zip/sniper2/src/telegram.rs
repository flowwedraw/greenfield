//! Модуль для взаимодействия с Telegram через протокол MTProto.
//!
//! Работает от имени пользовательского аккаунта (api_id + api_hash) через
//! grammers-client. Сессию храним в файле, чтобы не логиниться каждый раз.
//!
//! ВАЖНО: в config.channels имена каналов должны быть БЕЗ '@'.
//!
//! Оптимизация: кэшируем resolve_username -> PackedChat (ускоряет опрос).
//! ВАЖНО: при инициализации ставим watermark (last_id) равным текущему
//! последнему сообщению в канале — то есть игнорируем историю и слушаем
//! только новые сообщения, пришедшие ПОСЛЕ старта бота.

use anyhow::{Context, Result};
use grammers_client::{Client, Config as TgConfig, InitParams};
use grammers_client::types::PackedChat;
use grammers_session::Session;
use log::{debug, warn};
use regex::Regex;
use std::collections::HashMap;
use std::str::FromStr;

pub struct TelegramClient {
    client: Client,
    channels: Vec<String>,
    re_token: Regex,
    /// Последний обработанный message_id по каждому каналу (ключ — username без '@').
    last_ids: HashMap<String, i32>,
    /// Кэш username -> PackedChat (внутренний дескриптор чата).
    chat_cache: HashMap<String, PackedChat>,
    /// Сколько сообщений максимум подтягивать за один проход на канал (бэклог).
    max_backlog: usize,
}

impl TelegramClient {
    /// Создаёт новый клиент Telegram и подключается к сети.
    /// Сразу устанавливает watermark по каждому каналу на «последнее» сообщение.
    pub async fn new(
        api_id: i32,
        api_hash: &str,
        session_path: &str,
        channels: Vec<String>,
        max_backlog: usize,
    ) -> Result<Self> {
        let session = Session::load_file_or_create(session_path)
            .context("load/create telegram session")?;

        let client = Client::connect(TgConfig {
            session,
            api_id,
            api_hash: api_hash.to_string(),
            params: InitParams::default(),
        })
        .await
        .context("Не удалось подключиться к Telegram")?;

        if !client.is_authorized().await? {
            warn!("Сессия Telegram не авторизована. Выполните вход и сохраните сессию перед запуском бота.");
        }

        let re_token = Regex::new(r"[1-9A-HJ-NP-Za-km-z]{32,44}").unwrap();

        // Готовим кэши и сразу проставляем last_id = текущий последний id в канале,
        // чтобы игнорировать всю историю до старта бота.
        let mut last_ids = HashMap::new();
        let mut chat_cache = HashMap::new();

        for channel in &channels {
            match client.resolve_username(channel).await {
                Ok(Some(chat)) => {
                    let packed: PackedChat = chat.into();
                    // Попробуем узнать id самого свежего сообщения.
                    let mut it = client.iter_messages(packed.clone());
                    match it.next().await {
                        Ok(Some(m)) => {
                            let id = m.id();
                            last_ids.insert(channel.clone(), id);
                            debug!("Инициализация @{channel}: стартуем c last_id={id}");
                        }
                        Ok(None) => {
                            // В канале нет сообщений — стартуем с 0.
                            last_ids.insert(channel.clone(), 0);
                            debug!("Инициализация @{channel}: сообщений нет, last_id=0");
                        }
                        Err(e) => {
                            // Не валим бота: просто считаем, что истории нет.
                            last_ids.insert(channel.clone(), 0);
                            warn!("iter_messages для @{channel} вернул ошибку: {e}. Ставим last_id=0");
                        }
                    }
                    chat_cache.insert(channel.clone(), packed);
                }
                Ok(None) => {
                    // Канал не найден — оставим last_id=0 и попробуем позже на цикле.
                    last_ids.insert(channel.clone(), 0);
                    warn!("Не удалось найти канал @{channel} при инициализации");
                }
                Err(e) => {
                    last_ids.insert(channel.clone(), 0);
                    warn!("resolve_username @{channel} при инициализации: {e}. Ставим last_id=0");
                }
            }
        }

        Ok(Self {
            client,
            channels,
            re_token,
            last_ids,
            chat_cache,
            max_backlog,
        })
    }

    /// Достаём PackedChat из кэша, либо резолвим username один раз и кэшируем.
    async fn get_chat(&mut self, username: &str) -> Result<Option<PackedChat>> {
        if let Some(packed) = self.chat_cache.get(username) {
            return Ok(Some(packed.clone()));
        }
        match self.client.resolve_username(username).await {
            Ok(Some(chat)) => {
                let packed: PackedChat = chat.into();
                self.chat_cache.insert(username.to_string(), packed.clone());
                Ok(Some(packed))
            }
            Ok(None) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    /// Опрос каналов и получение **только новых** сообщений (текстов).
    pub async fn fetch_messages(&mut self) -> Result<Vec<String>> {
        let mut collected = Vec::new();
        let channels_snapshot = self.channels.clone();

        for channel_name in channels_snapshot {
            match self.get_chat(&channel_name).await? {
                Some(chat) => {
                    let mut iter = self.client.iter_messages(chat);

                    let prev_last_id = *self.last_ids.get(&channel_name).unwrap_or(&0);
                    let mut newest_id = prev_last_id;
                    let mut buffer = Vec::new();
                    let mut new_count = 0usize;
                    let mut pulled = 0usize;

                    while pulled < self.max_backlog {
                        match iter.next().await {
                            Ok(Some(msg)) => {
                                let id = msg.id();
                                if id <= prev_last_id {
                                    break;
                                }
                                let text = msg.text();
                                if !text.is_empty() {
                                    buffer.push(text.to_string());
                                    new_count += 1;
                                }
                                if id > newest_id {
                                    newest_id = id;
                                }
                                pulled += 1;
                            }
                            Ok(None) => break,
                            Err(e) => {
                                warn!(
                                    "iter_messages ошибка в @{channel}: {e}. Прерываем чтение канала на этот цикл.",
                                    channel = channel_name
                                );
                                break;
                            }
                        }
                    }

                    if newest_id > prev_last_id {
                        self.last_ids.insert(channel_name.clone(), newest_id);
                    }

                    buffer.reverse();
                    collected.extend(buffer);

                    debug!(
                        "Канал @{channel}: новых сообщений: {new_count}, прошлый last_id: {prev}, новый last_id: {new}",
                        channel = channel_name,
                        prev = prev_last_id,
                        new = self.last_ids.get(&channel_name).unwrap_or(&prev_last_id),
                    );
                }
                None => {
                    warn!("Не удалось найти канал @{channel}", channel = channel_name);
                }
            }
        }

        Ok(collected)
    }

    /// Ищет адрес токена (Base58 длиной 32–44) в тексте сообщения.
    pub fn parse_token_address(&self, msg: &str) -> Option<String> {
        use solana_sdk::pubkey::Pubkey;
        // Разбиваем сообщение по любым небуквенно-цифровым символам и ищем
        // первую строку, которую можно распарсить как Pubkey. Это надёжнее,
        // чем регулярное выражение по базе58. Если ни одного валидного ключа
        // не найдено, возвращаем None.
        for word in msg.split(|c: char| !c.is_alphanumeric()) {
            // Игнорируем слишком короткие/длинные строки
            if word.len() < 32 || word.len() > 44 {
                continue;
            }
            if let Ok(pk) = Pubkey::from_str(word) {
                // Возвращаем строковое представление валидного Pubkey
                return Some(pk.to_string());
            }
        }
        // Fallback: используем старую регулярку для совместимости
        self.re_token.find(msg).map(|m| m.as_str().to_string())
    }
}
